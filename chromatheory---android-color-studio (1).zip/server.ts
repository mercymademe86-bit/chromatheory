import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT || 3000;

app.use(express.json());

const apiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;
if (apiKey) {
  ai = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// AI Colorist Critique Endpoint
app.post('/api/ai-critique', async (req, res) => {
  try {
    const { colors, harmonyType, context } = req.body;
    if (!colors || !Array.isArray(colors) || colors.length === 0) {
      return res.status(400).json({ error: 'Please provide an array of hex colors' });
    }

    if (!ai) {
      return res.status(200).json({
        available: false,
        critique: 'Gemini API key is not configured. Algorithmic analysis is running offline in the applet.',
      });
    }

    const prompt = `You are a world-class color theorist, senior art director, and UI designer.
Critique this exact color palette:
Colors: ${colors.join(', ')}
Identified Harmony: ${harmonyType || 'Unknown'}
Intended Context: ${context || 'General Android mobile app / digital UI / branding'}

Provide a structured, constructive assessment:
1. Overall Impression & Visual Mood (2 sentences on the psychological feel and aesthetic coherence).
2. Harmony & Balance (Did they follow the color wheel rules? Are hues well proportioned or do they create eye vibration?).
3. Practical UI & Readability (Contrast notes, recommended dominant vs accent allocation, e.g. 60-30-10).
4. Concrete Refinement Suggestion (One specific adjustment to elevate the palette from good to sublime).

Keep the tone encouraging, expert, concise, and formatted with clean bullet points.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
    });

    return res.json({
      available: true,
      critique: response.text ?? 'No critique generated.',
    });
  } catch (error: any) {
    console.error('Gemini API Error:', error);
    return res.status(500).json({
      available: false,
      error: error.message || 'Failed to generate AI critique',
    });
  }
});

// AI Creative Theme Generator Endpoint
app.post('/api/ai-generate-theme', async (req, res) => {
  try {
    const { promptDescription } = req.body;
    if (!promptDescription) {
      return res.status(400).json({ error: 'Please provide a prompt description' });
    }

    if (!ai) {
      return res.status(200).json({
        available: false,
        error: 'Gemini API key not configured.',
      });
    }

    const prompt = `You are an expert colorist. Create an aesthetically breathtaking 5-color palette based on this inspiration:
"${promptDescription}"

Each color must be a valid 6-character hex code (e.g. #3B82F6).
Return ONLY a valid JSON object matching this schema:
{
  "title": "Creative Palette Name",
  "concept": "1 sentence explanation of why these colors reflect the prompt",
  "harmonyType": "Complementary | Analogous | Triadic | Split-Complementary | Monochromatic | Tetradic | Custom",
  "colors": [
    { "hex": "#...", "name": "Color Name", "role": "Dominant (60%) | Secondary (30%) | Accent (10%) | Surface | Text" },
    { "hex": "#...", "name": "Color Name", "role": "..." },
    { "hex": "#...", "name": "Color Name", "role": "..." },
    { "hex": "#...", "name": "Color Name", "role": "..." },
    { "hex": "#...", "name": "Color Name", "role": "..." }
  ]
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const parsed = JSON.parse(response.text ?? '{}');
    return res.json({ available: true, palette: parsed });
  } catch (error: any) {
    console.error('Theme generation error:', error);
    return res.status(500).json({
      available: false,
      error: error.message || 'Failed to generate theme',
    });
  }
});

// Setup Vite middlewares or static files
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
  });
}

startServer();
