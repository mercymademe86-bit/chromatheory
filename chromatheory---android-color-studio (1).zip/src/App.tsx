import React, { useState } from 'react';
import { CombinationAnalyzer } from './components/CombinationAnalyzer';
import { PaletteGenerator } from './components/PaletteGenerator';
import { TheoryLessons } from './components/TheoryLessons';
import { AndroidUiPreview } from './components/AndroidUiPreview';
import {
  Palette,
  Sliders,
  BookOpen,
  Smartphone,
  Sparkles,
  Info,
  Maximize2,
  Minimize2,
  Layers,
  Heart,
} from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<'analyzer' | 'generator' | 'lessons' | 'simulator'>('analyzer');
  const [isDeviceFrameMode, setIsDeviceFrameMode] = useState<boolean>(false);
  const [paletteForAnalyzer, setPaletteForAnalyzer] = useState<string[] | null>(null);

  // Default initial colors
  const [currentColors, setCurrentColors] = useState<string[]>([
    '#1E293B',
    '#3B82F6',
    '#F59E0B',
    '#F8FAFC',
  ]);

  const handleApplyPaletteToAnalyzer = (colors: string[]) => {
    setCurrentColors(colors);
    setActiveTab('analyzer');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center">
      
      {/* Top Application Header (Strict anti-slop Top Bar Contract) */}
      <header className="w-full max-w-5xl mx-auto flex items-center justify-between gap-8 px-4 sm:px-6 py-3.5 border-b border-slate-800/80 bg-slate-950/80 backdrop-blur-md sticky top-0 z-40">
        
        {/* Zone 1: Single text element wordmark */}
        <div className="flex items-center gap-2.5 shrink-0">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-indigo-600 to-pink-500 flex items-center justify-center shadow-md shadow-indigo-500/20">
            <Palette className="w-4 h-4 text-white" />
          </div>
          <span className="text-base font-bold tracking-tight text-white whitespace-nowrap">
            ChromaTheory
          </span>
        </div>

        {/* Zone 2: Single-line navigation links */}
        <nav className="hidden md:flex items-center gap-6 text-xs font-semibold text-slate-400">
          <button
            type="button"
            onClick={() => setActiveTab('analyzer')}
            className={`whitespace-nowrap transition-colors hover:text-white ${
              activeTab === 'analyzer' ? 'text-white' : ''
            }`}
          >
            Combination Analyzer
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('generator')}
            className={`whitespace-nowrap transition-colors hover:text-white ${
              activeTab === 'generator' ? 'text-white' : ''
            }`}
          >
            Palette Studio
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('lessons')}
            className={`whitespace-nowrap transition-colors hover:text-white ${
              activeTab === 'lessons' ? 'text-white' : ''
            }`}
          >
            Theory Masterclass
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('simulator')}
            className={`whitespace-nowrap transition-colors hover:text-white ${
              activeTab === 'simulator' ? 'text-white' : ''
            }`}
          >
            Android UI Preview
          </button>
        </nav>

        {/* Zone 3: Primary action / Frame toggle */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => setIsDeviceFrameMode(!isDeviceFrameMode)}
            className="min-h-[44px] px-3.5 py-1.5 bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-medium rounded-xl border border-slate-800 flex items-center gap-1.5 transition-colors"
            title="Toggle between phone frame and responsive layout"
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">
              {isDeviceFrameMode ? 'Wide Studio View' : 'Phone Frame Mode'}
            </span>
          </button>
        </div>
      </header>

      {/* Main Content Viewport */}
      <main className="w-full flex-1 flex flex-col items-center justify-start p-4 sm:p-6">
        
        {isDeviceFrameMode ? (
          /* Android Smartphone Frame Wrapper */
          <div className="w-full max-w-[420px] rounded-[40px] border-[8px] border-slate-800 bg-slate-950 shadow-2xl overflow-hidden flex flex-col min-h-[780px] max-h-[880px] relative">
            
            {/* Camera Punch-Hole & Status bar */}
            <div className="w-full pt-2 px-6 flex items-center justify-between text-[11px] font-mono text-slate-400 bg-slate-950 shrink-0">
              <span>09:41</span>
              <div className="w-3.5 h-3.5 rounded-full bg-slate-900 border border-slate-800" />
              <span>5G · 98%</span>
            </div>

            {/* Scrollable Mobile App Area */}
            <div className="flex-1 overflow-y-auto p-4 pb-24">
              {activeTab === 'analyzer' && <CombinationAnalyzer />}
              {activeTab === 'generator' && (
                <PaletteGenerator onSendToAnalyzer={handleApplyPaletteToAnalyzer} />
              )}
              {activeTab === 'lessons' && (
                <TheoryLessons onApplyPaletteToAnalyzer={handleApplyPaletteToAnalyzer} />
              )}
              {activeTab === 'simulator' && (
                <div className="flex flex-col items-center py-4">
                  <AndroidUiPreview colors={currentColors} />
                </div>
              )}
            </div>

            {/* Mobile Bottom Gesture Bar */}
            <div className="absolute bottom-16 left-0 right-0 flex justify-center pointer-events-none">
              <div className="w-28 h-1 rounded-full bg-slate-600/50" />
            </div>

          </div>
        ) : (
          /* Full Wide Responsive Studio Layout */
          <div className="w-full max-w-5xl">
            {activeTab === 'analyzer' && <CombinationAnalyzer />}
            {activeTab === 'generator' && (
              <PaletteGenerator onSendToAnalyzer={handleApplyPaletteToAnalyzer} />
            )}
            {activeTab === 'lessons' && (
              <TheoryLessons onApplyPaletteToAnalyzer={handleApplyPaletteToAnalyzer} />
            )}
            {activeTab === 'simulator' && (
              <div className="flex flex-col items-center py-6">
                <AndroidUiPreview colors={currentColors} />
              </div>
            )}
          </div>
        )}

      </main>

      {/* Android Fixed Bottom Navigation Bar (Pattern 1 from Mobile Touch reference) */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 bg-slate-950/90 backdrop-blur-md border-t border-slate-800/80 px-2 py-1 max-w-md mx-auto sm:max-w-none">
        <div className="max-w-md mx-auto grid grid-cols-4 items-center h-16">
          
          <button
            type="button"
            onClick={() => setActiveTab('analyzer')}
            className={`min-h-[44px] min-w-[44px] flex flex-col items-center justify-center transition-colors ${
              activeTab === 'analyzer' ? 'text-indigo-400 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Sliders className="w-5 h-5" />
            <span className="text-[10px] tracking-tight mt-1">Analyzer</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('generator')}
            className={`min-h-[44px] min-w-[44px] flex flex-col items-center justify-center transition-colors ${
              activeTab === 'generator' ? 'text-indigo-400 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Palette className="w-5 h-5" />
            <span className="text-[10px] tracking-tight mt-1">Generator</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('lessons')}
            className={`min-h-[44px] min-w-[44px] flex flex-col items-center justify-center transition-colors ${
              activeTab === 'lessons' ? 'text-indigo-400 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <BookOpen className="w-5 h-5" />
            <span className="text-[10px] tracking-tight mt-1">Lessons</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('simulator')}
            className={`min-h-[44px] min-w-[44px] flex flex-col items-center justify-center transition-colors ${
              activeTab === 'simulator' ? 'text-indigo-400 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Smartphone className="w-5 h-5" />
            <span className="text-[10px] tracking-tight mt-1">Mockup</span>
          </button>

        </div>
      </nav>

    </div>
  );
}
