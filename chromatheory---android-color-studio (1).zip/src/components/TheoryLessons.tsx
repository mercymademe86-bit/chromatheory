import React, { useState } from 'react';
import { COLOR_THEORY_LESSONS, Lesson, QuizQuestion } from '../data/lessonsData';
import {
  BookOpen,
  CheckCircle2,
  XCircle,
  HelpCircle,
  ChevronRight,
  ArrowLeft,
  RotateCcw,
  Sparkles,
  Award,
  Disc,
  ArrowLeftRight,
  Triangle,
  Square,
  Layers,
  Flame,
  Wand2,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { hexToHsl, hslToHex } from '../utils/colorMath';

interface TheoryLessonsProps {
  onApplyPaletteToAnalyzer?: (colors: string[]) => void;
}

export const TheoryLessons: React.FC<TheoryLessonsProps> = ({ onApplyPaletteToAnalyzer }) => {
  const [selectedLessonId, setSelectedLessonId] = useState<string | null>(null);
  const [quizAnswers, setQuizAnswers] = useState<Record<string, number>>({});
  const [showExplanations, setShowExplanations] = useState<Record<string, boolean>>({});
  
  // Interactive widget states for lessons
  const [interactiveHue, setInteractiveHue] = useState<number>(210);
  const [interactiveLightness, setInteractiveLightness] = useState<number>(50);
  const [interactiveTempBalance, setInteractiveTempBalance] = useState<number>(50);

  const activeLesson = COLOR_THEORY_LESSONS.find((l) => l.id === selectedLessonId);

  const handleSelectAnswer = (questionId: string, optionIndex: number, correctIndex: number) => {
    setQuizAnswers((prev) => ({ ...prev, [questionId]: optionIndex }));
    setShowExplanations((prev) => ({ ...prev, [questionId]: true }));

    if (optionIndex === correctIndex) {
      try {
        confetti({
          particleCount: 35,
          spread: 60,
          origin: { y: 0.8 },
        });
      } catch {}
    }
  };

  const getLessonIcon = (iconName: string) => {
    switch (iconName) {
      case 'Disc':
        return <Disc className="w-5 h-5 text-indigo-400" />;
      case 'ArrowLeftRight':
        return <ArrowLeftRight className="w-5 h-5 text-amber-400" />;
      case 'Triangle':
        return <Triangle className="w-5 h-5 text-emerald-400" />;
      case 'Square':
        return <Square className="w-5 h-5 text-cyan-400" />;
      case 'Layers':
        return <Layers className="w-5 h-5 text-purple-400" />;
      case 'Flame':
        return <Flame className="w-5 h-5 text-rose-400" />;
      default:
        return <BookOpen className="w-5 h-5 text-indigo-400" />;
    }
  };

  // Render Lesson Detail
  if (activeLesson) {
    const isCompleted = activeLesson.quiz.every(
      (q) => quizAnswers[q.id] === q.correctIndex
    );

    return (
      <div className="flex flex-col gap-6 max-w-3xl mx-auto w-full pb-20 animate-in fade-in duration-200">
        
        {/* Navigation Bar */}
        <div className="flex items-center justify-between">
          <button
            type="button"
            onClick={() => setSelectedLessonId(null)}
            className="min-h-[44px] px-3 py-2 bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-semibold rounded-xl flex items-center gap-2 border border-slate-800 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>All Lessons</span>
          </button>

          <span className="text-xs text-slate-400">
            {activeLesson.category} · {activeLesson.readTime}
          </span>
        </div>

        {/* Lesson Hero Header */}
        <div className="bg-slate-900 border border-slate-800 p-6 rounded-3xl shadow-xl flex flex-col gap-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800">
              {getLessonIcon(activeLesson.iconName)}
            </div>
            <div>
              <h2 className="text-xl font-bold text-slate-100">{activeLesson.title}</h2>
              <p className="text-xs text-indigo-400 font-medium">{activeLesson.tagline}</p>
            </div>
          </div>

          <p className="text-xs text-slate-300 leading-relaxed mt-1">
            {activeLesson.summary}
          </p>

          {/* Palette Swatches Bar */}
          <div className="flex items-center justify-between pt-3 border-t border-slate-800">
            <div className="flex items-center gap-1.5">
              {activeLesson.demoColors.map((color, idx) => (
                <div
                  key={`demo-c-${idx}`}
                  className="w-8 h-8 rounded-lg border border-white/20 shadow-sm"
                  style={{ backgroundColor: color }}
                  title={color}
                />
              ))}
            </div>

            {onApplyPaletteToAnalyzer && (
              <button
                type="button"
                onClick={() => onApplyPaletteToAnalyzer(activeLesson.demoColors)}
                className="min-h-[44px] px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-all shadow-md shadow-indigo-600/20 active:scale-95"
              >
                <Wand2 className="w-3.5 h-3.5" />
                <span>Test in Analyzer</span>
              </button>
            )}
          </div>
        </div>

        {/* Interactive Theory Demonstration Widget */}
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl shadow-xl flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-100">Interactive Visual Laboratory</h3>
            <span className="text-[11px] text-slate-400">Live Feedback</span>
          </div>

          {/* Widget Type 1: Complementary Contrast Slider */}
          {activeLesson.id === 'complementary' && (
            <div className="flex flex-col gap-4 bg-slate-950 p-4 rounded-2xl border border-slate-800">
              <div className="flex flex-col gap-1">
                <div className="flex justify-between text-xs text-slate-300">
                  <span>Base Hue Rotation</span>
                  <span className="font-mono text-indigo-400">{interactiveHue}°</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="359"
                  value={interactiveHue}
                  onChange={(e) => setInteractiveHue(Number(e.target.value))}
                  className="w-full h-2 rounded-lg appearance-none cursor-pointer"
                  style={{
                    background: 'linear-gradient(to right, #f00 0%, #ff0 17%, #0f0 33%, #0ff 50%, #00f 67%, #f0f 83%, #f00 100%)',
                  }}
                />
              </div>

              {/* Complementary Pair Display */}
              <div className="grid grid-cols-2 gap-3">
                <div
                  className="h-24 rounded-xl p-3 flex flex-col justify-between border border-white/10 shadow-inner"
                  style={{ backgroundColor: hslToHex(interactiveHue, 80, 45) }}
                >
                  <span className="text-xs font-bold text-white bg-black/40 px-2 py-0.5 rounded w-fit">
                    Primary Hue ({interactiveHue}°)
                  </span>
                  <span className="text-xs font-mono font-bold text-white">
                    {hslToHex(interactiveHue, 80, 45)}
                  </span>
                </div>

                <div
                  className="h-24 rounded-xl p-3 flex flex-col justify-between border border-white/10 shadow-inner"
                  style={{ backgroundColor: hslToHex((interactiveHue + 180) % 360, 85, 55) }}
                >
                  <span className="text-xs font-bold text-slate-900 bg-white/70 px-2 py-0.5 rounded w-fit">
                    Complement ({((interactiveHue + 180) % 360)}°)
                  </span>
                  <span className="text-xs font-mono font-bold text-slate-900">
                    {hslToHex((interactiveHue + 180) % 360, 85, 55)}
                  </span>
                </div>
              </div>

              <p className="text-[11px] text-slate-400 leading-relaxed">
                Notice how rotating the primary color automatically updates its 180° polar opposite. Placing these two together provides the highest perceptual chromatic tension.
              </p>
            </div>
          )}

          {/* Widget Type 2: Triadic Balance (120° offsets) */}
          {activeLesson.id === 'triadic' && (
            <div className="flex flex-col gap-4 bg-slate-950 p-4 rounded-2xl border border-slate-800">
              <div className="flex flex-col gap-1">
                <div className="flex justify-between text-xs text-slate-300">
                  <span>Equilateral Triad Base</span>
                  <span className="font-mono text-indigo-400">{interactiveHue}°</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="359"
                  value={interactiveHue}
                  onChange={(e) => setInteractiveHue(Number(e.target.value))}
                  className="w-full h-2 rounded-lg appearance-none cursor-pointer"
                  style={{
                    background: 'linear-gradient(to right, #f00 0%, #ff0 17%, #0f0 33%, #0ff 50%, #00f 67%, #f0f 83%, #f00 100%)',
                  }}
                />
              </div>

              <div className="grid grid-cols-3 gap-2">
                {[0, 120, 240].map((offset, i) => {
                  const hue = (interactiveHue + offset) % 360;
                  const hex = hslToHex(hue, 75, 50);
                  return (
                    <div
                      key={`triad-${i}`}
                      className="h-20 rounded-xl p-2.5 flex flex-col justify-between border border-white/10"
                      style={{ backgroundColor: hex }}
                    >
                      <span className="text-[10px] font-bold text-white bg-black/40 px-1.5 py-0.5 rounded w-fit">
                        {offset === 0 ? 'Anchor' : `+${offset}°`}
                      </span>
                      <span className="text-[11px] font-mono font-bold text-white">
                        {hex}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Widget Type 3: Monochromatic Tints & Shades */}
          {activeLesson.id === 'monochromatic' && (
            <div className="flex flex-col gap-4 bg-slate-950 p-4 rounded-2xl border border-slate-800">
              <div className="flex flex-col gap-1">
                <div className="flex justify-between text-xs text-slate-300">
                  <span>Base Hue</span>
                  <span className="font-mono text-indigo-400">{interactiveHue}°</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="359"
                  value={interactiveHue}
                  onChange={(e) => setInteractiveHue(Number(e.target.value))}
                  className="w-full h-2 rounded-lg appearance-none cursor-pointer"
                  style={{
                    background: 'linear-gradient(to right, #f00 0%, #ff0 17%, #0f0 33%, #0ff 50%, #00f 67%, #f0f 83%, #f00 100%)',
                  }}
                />
              </div>

              <div className="grid grid-cols-5 gap-1.5">
                {[15, 30, 50, 70, 90].map((lightness, idx) => {
                  const hex = hslToHex(interactiveHue, 70, lightness);
                  return (
                    <div
                      key={`mono-${idx}`}
                      className="h-20 rounded-xl p-2 flex flex-col justify-between border border-white/10 text-[10px]"
                      style={{ backgroundColor: hex }}
                    >
                      <span className={lightness > 60 ? 'text-slate-900 font-bold' : 'text-white font-bold'}>
                        {lightness < 40 ? 'Shade' : lightness > 65 ? 'Tint' : 'Midtone'}
                      </span>
                      <span className={`font-mono ${lightness > 60 ? 'text-slate-900' : 'text-white'}`}>
                        {lightness}%L
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Widget Type 4: Warm vs Cool Temperature Balance */}
          {activeLesson.id === 'warm-cool' && (
            <div className="flex flex-col gap-4 bg-slate-950 p-4 rounded-2xl border border-slate-800">
              <div className="flex justify-between items-center text-xs">
                <span className="text-amber-400 font-bold">Warm (Advancing)</span>
                <span className="text-cyan-400 font-bold">Cool (Receding)</span>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="p-3.5 rounded-xl bg-gradient-to-br from-red-600 via-orange-500 to-amber-500 text-white flex flex-col gap-2">
                  <span className="text-xs font-bold uppercase tracking-wider">Warm Spectrum</span>
                  <p className="text-[11px] leading-relaxed text-white/90">
                    Longer wavelengths trigger focal lens thickening in the human eye, causing warm elements to visually advance toward the user. Ideal for CTAs, alarms, and highlights.
                  </p>
                </div>

                <div className="p-3.5 rounded-xl bg-gradient-to-br from-indigo-700 via-blue-600 to-teal-500 text-white flex flex-col gap-2">
                  <span className="text-xs font-bold uppercase tracking-wider">Cool Spectrum</span>
                  <p className="text-[11px] leading-relaxed text-white/90">
                    Shorter wavelengths recede into the canvas, evoking serenity, focus, and stability. Ideal for app backgrounds, large containers, and navigational structure.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Widget Type 5: Tetradic Box Geometry */}
          {(activeLesson.id === 'tetradic' || activeLesson.id === 'color-wheel') && (
            <div className="grid grid-cols-4 gap-2 bg-slate-950 p-3.5 rounded-2xl border border-slate-800">
              {activeLesson.demoColors.slice(0, 4).map((c, i) => (
                <div
                  key={`box-${i}`}
                  className="h-16 rounded-xl flex flex-col items-center justify-center border border-white/10"
                  style={{ backgroundColor: c }}
                >
                  <span className="text-xs font-mono font-bold text-white bg-black/40 px-2 py-0.5 rounded">
                    {c}
                  </span>
                </div>
              ))}
            </div>
          )}

        </div>

        {/* Deep Dive Theory Text & Guidelines */}
        <div className="flex flex-col gap-4">
          <h3 className="text-sm font-bold text-slate-100">Theoretical Foundations</h3>

          {activeLesson.deepDive.map((section, idx) => (
            <div
              key={`deep-${idx}`}
              className="bg-slate-900 border border-slate-800 p-5 rounded-3xl shadow-md flex flex-col gap-2.5"
            >
              <h4 className="text-sm font-bold text-indigo-300">{section.sectionTitle}</h4>
              {section.paragraphs.map((p, pIdx) => (
                <p key={`p-${pIdx}`} className="text-xs text-slate-300 leading-relaxed">
                  {p}
                </p>
              ))}
            </div>
          ))}

          {/* Key Takeaways */}
          <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl shadow-md flex flex-col gap-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Key Takeaways
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {activeLesson.keyPoints.map((point, idx) => (
                <div
                  key={`kp-${idx}`}
                  className="p-3 bg-slate-950 rounded-xl border border-slate-800/80 flex items-start gap-2.5"
                >
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span className="text-xs text-slate-300 leading-snug">{point}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Interactive Knowledge Quiz Section */}
        <div className="bg-slate-900 border border-slate-800 p-6 rounded-3xl shadow-xl flex flex-col gap-5">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <Award className="w-5 h-5 text-amber-400" />
              <h3 className="text-sm font-bold text-slate-100">Test Your Knowledge</h3>
            </div>
            {isCompleted && (
              <span className="text-xs font-semibold text-emerald-400 flex items-center gap-1">
                <CheckCircle2 className="w-4 h-4" /> Passed
              </span>
            )}
          </div>

          <div className="flex flex-col gap-6">
            {activeLesson.quiz.map((q, qIndex) => {
              const selectedOpt = quizAnswers[q.id];
              const isAnswered = selectedOpt !== undefined;
              const isCorrect = selectedOpt === q.correctIndex;

              return (
                <div
                  key={q.id}
                  className="p-4 bg-slate-950 rounded-2xl border border-slate-800/80 flex flex-col gap-3"
                >
                  <span className="text-xs font-bold text-slate-200">
                    Question {qIndex + 1}: {q.question}
                  </span>

                  {/* Options */}
                  <div className="flex flex-col gap-2">
                    {q.options.map((option, optIdx) => {
                      const isOptionSelected = selectedOpt === optIdx;
                      const isOptionCorrect = optIdx === q.correctIndex;

                      let btnStyle = 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700';
                      if (isAnswered) {
                        if (isOptionCorrect) {
                          btnStyle = 'bg-emerald-950/60 border-emerald-500 text-emerald-200';
                        } else if (isOptionSelected) {
                          btnStyle = 'bg-rose-950/60 border-rose-500 text-rose-200';
                        } else {
                          btnStyle = 'opacity-40 bg-slate-900 border-slate-800 text-slate-400';
                        }
                      }

                      return (
                        <button
                          key={`opt-${optIdx}`}
                          type="button"
                          disabled={isAnswered}
                          onClick={() => handleSelectAnswer(q.id, optIdx, q.correctIndex)}
                          className={`min-h-[44px] px-4 py-2.5 rounded-xl border text-xs text-left font-medium flex items-center justify-between transition-colors ${btnStyle}`}
                        >
                          <span>{option}</span>
                          {isAnswered && isOptionCorrect && (
                            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                          )}
                          {isAnswered && isOptionSelected && !isOptionCorrect && (
                            <XCircle className="w-4 h-4 text-rose-400 shrink-0" />
                          )}
                        </button>
                      );
                    })}
                  </div>

                  {/* Explanation Card */}
                  {isAnswered && (
                    <div
                      className={`p-3 rounded-xl border text-xs leading-relaxed ${
                        isCorrect
                          ? 'bg-emerald-950/30 border-emerald-800 text-emerald-200'
                          : 'bg-rose-950/30 border-rose-800 text-rose-200'
                      }`}
                    >
                      <span className="font-bold block mb-1">
                        {isCorrect ? 'Correct!' : 'Incorrect'}
                      </span>
                      {q.explanation}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

      </div>
    );
  }

  // Render Lesson Catalog List
  return (
    <div className="flex flex-col gap-6 max-w-4xl mx-auto w-full pb-20">
      
      {/* Catalog Header */}
      <div className="bg-slate-900 border border-slate-800 p-6 rounded-3xl shadow-xl flex flex-col gap-2">
        <div className="flex items-center gap-2 text-xs font-semibold text-indigo-400">
          <BookOpen className="w-4 h-4" />
          <span>Interactive Academy</span>
        </div>
        <h2 className="text-xl font-bold text-slate-100">Color Theory Masterclass</h2>
        <p className="text-xs text-slate-300 leading-relaxed max-w-2xl">
          Learn how light, physiology, and geometry govern human visual pleasure. Each lesson features interactive sandbox widgets and comprehension quizzes.
        </p>
      </div>

      {/* Lesson Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {COLOR_THEORY_LESSONS.map((lesson) => (
          <div
            key={lesson.id}
            onClick={() => setSelectedLessonId(lesson.id)}
            className="group p-5 bg-slate-900 border border-slate-800 hover:border-indigo-500/50 hover:bg-slate-850 rounded-3xl shadow-md cursor-pointer transition-all flex flex-col justify-between gap-4"
          >
            <div className="flex flex-col gap-2.5">
              <div className="flex items-center justify-between">
                <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800">
                  {getLessonIcon(lesson.iconName)}
                </div>
                <span className="text-[11px] text-slate-400">
                  {lesson.category} · {lesson.readTime}
                </span>
              </div>

              <div>
                <h3 className="text-base font-bold text-slate-100 group-hover:text-indigo-300 transition-colors">
                  {lesson.title}
                </h3>
                <p className="text-xs text-indigo-400 font-medium mt-0.5">
                  {lesson.tagline}
                </p>
                <p className="text-xs text-slate-300 mt-2 line-clamp-2 leading-relaxed">
                  {lesson.summary}
                </p>
              </div>
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-slate-800/80">
              {/* Color Swatches */}
              <div className="flex items-center gap-1">
                {lesson.demoColors.slice(0, 4).map((c, i) => (
                  <div
                    key={`lc-${i}`}
                    className="w-5 h-5 rounded-full border border-white/20"
                    style={{ backgroundColor: c }}
                  />
                ))}
              </div>

              <div className="flex items-center gap-1 text-xs font-semibold text-slate-300 group-hover:text-indigo-300 transition-colors">
                <span>Start Lesson</span>
                <ChevronRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
              </div>
            </div>
          </div>
        ))}
      </div>

    </div>
  );
};
