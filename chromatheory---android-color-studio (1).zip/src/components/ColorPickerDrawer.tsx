import React, { useState, useEffect } from 'react';
import { hexToHsl, hslToHex, hexToRgb, rgbToHex } from '../utils/colorMath';
import { Pipette, X, Check, RotateCcw } from 'lucide-react';

interface ColorPickerDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  currentColor: string;
  onApplyColor: (color: string) => void;
  colorIndex: number;
}

const PRESET_SWATCHES = [
  '#2563EB', '#3B82F6', '#60A5FA', '#0284C7', '#06B6D4', '#0D9488',
  '#10B981', '#84CC16', '#EAB308', '#F59E0B', '#F97316', '#EF4444',
  '#E11D48', '#EC4899', '#D946EF', '#8B5CF6', '#6366F1', '#475569',
  '#0F172A', '#F8FAFC', '#FBBF24', '#34D399', '#A78BFA', '#F43F5E'
];

export const ColorPickerDrawer: React.FC<ColorPickerDrawerProps> = ({
  isOpen,
  onClose,
  currentColor,
  onApplyColor,
  colorIndex,
}) => {
  const [hexInput, setHexInput] = useState(currentColor);
  const [hsl, setHsl] = useState(() => hexToHsl(currentColor));
  const [rgb, setRgb] = useState(() => hexToRgb(currentColor));

  useEffect(() => {
    setHexInput(currentColor);
    setHsl(hexToHsl(currentColor));
    setRgb(hexToRgb(currentColor));
  }, [currentColor, isOpen]);

  if (!isOpen) return null;

  const updateFromHsl = (newH: number, newS: number, newL: number) => {
    const clampedH = ((newH % 360) + 360) % 360;
    const clampedS = Math.max(0, Math.min(100, newS));
    const clampedL = Math.max(0, Math.min(100, newL));
    setHsl({ h: clampedH, s: clampedS, l: clampedL });
    const newHex = hslToHex(clampedH, clampedS, clampedL);
    setHexInput(newHex);
    setRgb(hexToRgb(newHex));
  };

  const updateFromHex = (val: string) => {
    let clean = val.trim();
    if (!clean.startsWith('#')) clean = '#' + clean;
    setHexInput(clean);
    if (/^#[0-9A-Fa-f]{6}$/.test(clean)) {
      setHsl(hexToHsl(clean));
      setRgb(hexToRgb(clean));
    }
  };

  const handleEyedropper = async () => {
    if ('EyeDropper' in window) {
      try {
        const eyeDropper = new (window as any).EyeDropper();
        const result = await eyeDropper.open();
        if (result?.sRGBHex) {
          updateFromHex(result.sRGBHex);
        }
      } catch (e) {
        // user canceled or not permitted
      }
    }
  };

  const handleConfirm = () => {
    if (/^#[0-9A-Fa-f]{6}$/.test(hexInput)) {
      onApplyColor(hexInput);
    } else {
      onApplyColor(hslToHex(hsl.h, hsl.s, hsl.l));
    }
    onClose();
  };

  const activeHex = /^#[0-9A-Fa-f]{6}$/.test(hexInput) ? hexInput : hslToHex(hsl.h, hsl.s, hsl.l);

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-sm p-0 sm:p-4 animate-in fade-in duration-200">
      <div className="w-full sm:max-w-md bg-slate-900 border border-slate-800 rounded-t-3xl sm:rounded-2xl p-5 shadow-2xl flex flex-col gap-4 max-h-[90vh] overflow-y-auto">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-2 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <span
              className="w-5 h-5 rounded-full border border-white/20 shadow-sm"
              style={{ backgroundColor: activeHex }}
            />
            <h3 className="text-sm font-semibold text-slate-100">
              Edit Color {colorIndex + 1}
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-100 rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Live Comparison Swatch & Eyedropper */}
        <div className="flex items-center gap-3 bg-slate-950 p-3 rounded-xl border border-slate-800/80">
          <div className="flex-1 flex flex-col gap-1">
            <span className="text-[11px] text-slate-400">Current Preview</span>
            <div
              className="h-12 w-full rounded-lg border border-white/10 shadow-inner flex items-center justify-center transition-colors"
              style={{ backgroundColor: activeHex }}
            >
              <span className={`text-xs font-mono font-bold ${hsl.l > 55 ? 'text-slate-950' : 'text-white'}`}>
                {activeHex}
              </span>
            </div>
          </div>

          {'EyeDropper' in window && (
            <button
              type="button"
              onClick={handleEyedropper}
              className="min-h-[44px] min-w-[44px] flex flex-col items-center justify-center gap-1 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg transition-colors border border-slate-700"
              title="Sample color from screen"
            >
              <Pipette className="w-4 h-4" />
              <span className="text-[10px]">Sample</span>
            </button>
          )}
        </div>

        {/* Sliders: Hue, Saturation, Lightness */}
        <div className="flex flex-col gap-3">
          {/* Hue Slider */}
          <div className="flex flex-col gap-1">
            <div className="flex justify-between text-xs text-slate-300">
              <span>Hue</span>
              <span className="font-mono text-slate-400">{hsl.h}°</span>
            </div>
            <input
              type="range"
              min="0"
              max="359"
              value={hsl.h}
              onChange={(e) => updateFromHsl(Number(e.target.value), hsl.s, hsl.l)}
              className="w-full h-3 rounded-lg appearance-none cursor-pointer"
              style={{
                background: 'linear-gradient(to right, #f00 0%, #ff0 17%, #0f0 33%, #0ff 50%, #00f 67%, #f0f 83%, #f00 100%)',
              }}
            />
          </div>

          {/* Saturation Slider */}
          <div className="flex flex-col gap-1">
            <div className="flex justify-between text-xs text-slate-300">
              <span>Saturation</span>
              <span className="font-mono text-slate-400">{hsl.s}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              value={hsl.s}
              onChange={(e) => updateFromHsl(hsl.h, Number(e.target.value), hsl.l)}
              className="w-full h-3 rounded-lg appearance-none cursor-pointer"
              style={{
                background: `linear-gradient(to right, hsl(${hsl.h}, 0%, ${hsl.l}%), hsl(${hsl.h}, 100%, ${hsl.l}%))`,
              }}
            />
          </div>

          {/* Lightness Slider */}
          <div className="flex flex-col gap-1">
            <div className="flex justify-between text-xs text-slate-300">
              <span>Lightness / Value</span>
              <span className="font-mono text-slate-400">{hsl.l}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              value={hsl.l}
              onChange={(e) => updateFromHsl(hsl.h, hsl.s, Number(e.target.value))}
              className="w-full h-3 rounded-lg appearance-none cursor-pointer"
              style={{
                background: `linear-gradient(to right, #000000, hsl(${hsl.h}, ${hsl.s}%, 50%), #ffffff)`,
              }}
            />
          </div>
        </div>

        {/* Hex Input & Coordinates */}
        <div className="grid grid-cols-2 gap-2 pt-1">
          <div>
            <label className="text-[11px] text-slate-400 block mb-1">Hex Code</label>
            <input
              type="text"
              value={hexInput}
              maxLength={7}
              onChange={(e) => updateFromHex(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs font-mono text-slate-100 uppercase focus:outline-none focus:border-indigo-500"
              placeholder="#3B82F6"
            />
          </div>
          <div>
            <label className="text-[11px] text-slate-400 block mb-1">RGB Values</label>
            <div className="px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs font-mono text-slate-300">
              {rgb.r}, {rgb.g}, {rgb.b}
            </div>
          </div>
        </div>

        {/* Quick Swatches Palette */}
        <div>
          <span className="text-[11px] text-slate-400 block mb-1.5">Quick Swatches</span>
          <div className="grid grid-cols-8 gap-1.5">
            {PRESET_SWATCHES.map((swatch) => (
              <button
                key={swatch}
                type="button"
                onClick={() => updateFromHex(swatch)}
                className={`w-full aspect-square rounded-md transition-transform hover:scale-110 active:scale-95 ${
                  activeHex.toUpperCase() === swatch.toUpperCase()
                    ? 'ring-2 ring-white ring-offset-1 ring-offset-slate-900 scale-105'
                    : 'border border-white/10'
                }`}
                style={{ backgroundColor: swatch }}
                title={swatch}
              />
            ))}
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2 pt-2 border-t border-slate-800">
          <button
            type="button"
            onClick={() => updateFromHex(currentColor)}
            className="min-h-[44px] px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium rounded-xl flex items-center gap-1.5 transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset</span>
          </button>
          <button
            type="button"
            onClick={handleConfirm}
            className="min-h-[44px] flex-1 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-xl flex items-center justify-center gap-2 transition-all shadow-md shadow-indigo-600/20 active:scale-[0.98]"
          >
            <Check className="w-4 h-4" />
            <span>Apply Color</span>
          </button>
        </div>

      </div>
    </div>
  );
};
