import React, { useState } from 'react';
import {
  analyzeHarmony,
  evaluateAestheticPleasingness,
  checkWcag,
  harmonizePalette,
  simulateColorBlindness,
  ColorBlindnessType,
  hexToHsl,
  getRelativeLuminance,
} from '../utils/colorMath';
import { ColorWheel } from './ColorWheel';
import { ColorPickerDrawer } from './ColorPickerDrawer';
import { AndroidUiPreview } from './AndroidUiPreview';
import {
  Sparkles,
  Shuffle,
  Wand2,
  CheckCircle,
  AlertTriangle,
  Info,
  Eye,
  Plus,
  Trash2,
  Layers,
  HelpCircle,
  Sliders,
  ChevronDown,
  Bot,
} from 'lucide-react';

interface PresetCombo {
  name: string;
  category: string;
  colors: string[];
}

const PRESET_COMBOS: PresetCombo[] = [
  {
    name: 'Material Indigo (Complementary)',
    category: 'Harmonious',
    colors: ['#1E1B4B', '#4F46E5', '#F59E0B', '#F8FAFC'],
  },
  {
    name: 'Emerald Aurora (Analogous)',
    category: 'Harmonious',
    colors: ['#064E3B', '#059669', '#10B981', '#34D399'],
  },
  {
    name: 'Bauhaus Primary (Triadic)',
    category: 'Harmonious',
    colors: ['#2563EB', '#DC2626', '#EAB308', '#F8FAFC'],
  },
  {
    name: 'Cyberpunk Neon (Split-Comp)',
    category: 'Vibrant',
    colors: ['#0F172A', '#06B6D4', '#EC4899', '#A855F7'],
  },
  {
    name: 'Discordant Clash (Vibrating Edges)',
    category: 'Clashing Example',
    colors: ['#FF0000', '#00FF00', '#0000FF', '#FF00FF'],
  },
  {
    name: 'Low-Contrast Muddy (Flat Luminance)',
    category: 'Clashing Example',
    colors: ['#7C3AED', '#2563EB', '#059669', '#D97706'],
  },
];

export const CombinationAnalyzer: React.FC = () => {
  // Input colors (2 to 4 colors)
  const [colors, setColors] = useState<string[]>([
    '#1E293B',
    '#3B82F6',
    '#F59E0B',
    '#F8FAFC',
  ]);

  const [selectedColorIndex, setSelectedColorIndex] = useState<number>(1);
  const [isPickerOpen, setIsPickerOpen] = useState(false);
  const [activeBlindness, setActiveBlindness] = useState<ColorBlindnessType>('normal');
  const [aiCritique, setAiCritique] = useState<string | null>(null);
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<'analysis' | 'accessibility' | 'preview'>('analysis');

  // Perform theoretical analysis
  const harmony = analyzeHarmony(colors);
  const aesthetic = evaluateAestheticPleasingness(colors);

  // Filter colors with color blindness simulation if active
  const displayedColors = colors.map((c) => simulateColorBlindness(c, activeBlindness));

  const handleColorChange = (index: number, newHex: string) => {
    const updated = [...colors];
    updated[index] = newHex;
    setColors(updated);
  };

  const handleAddColor = () => {
    if (colors.length >= 4) return;
    const baseHsl = hexToHsl(colors[colors.length - 1] || '#3B82F6');
    const newHue = (baseHsl.h + 60) % 360;
    // generate pleasant fourth color
    const newHex = colors.length === 2 ? '#F59E0B' : '#EC4899';
    setColors([...colors, newHex]);
    setSelectedColorIndex(colors.length);
  };

  const handleRemoveColor = (index: number) => {
    if (colors.length <= 2) return; // Keep at least 2 for combination analysis
    const updated = colors.filter((_, i) => i !== index);
    setColors(updated);
    if (selectedColorIndex >= updated.length) {
      setSelectedColorIndex(updated.length - 1);
    }
  };

  const handleRandomize = () => {
    const randomHex = () =>
      '#' + Math.floor(Math.random() * 16777215).toString(16).padStart(6, '0').toUpperCase();
    const count = colors.length;
    const newColors: string[] = [];
    for (let i = 0; i < count; i++) {
      newColors.push(randomHex());
    }
    setColors(newColors);
    setAiCritique(null);
  };

  const handleHarmonize = () => {
    const optimized = harmonizePalette(colors, harmony.type);
    setColors(optimized);
    setAiCritique(null);
  };

  const handleRequestAiCritique = async () => {
    setIsAiLoading(true);
    setAiCritique(null);
    try {
      const res = await fetch('/api/ai-critique', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          colors,
          harmonyType: harmony.type,
          context: 'Android Mobile Application Material Design 3',
        }),
      });
      const data = await res.json();
      if (data.critique) {
        setAiCritique(data.critique);
      } else if (data.error) {
        setAiCritique(`AI Colorist note: ${data.error}`);
      }
    } catch (e: any) {
      setAiCritique('Could not reach AI Colorist server endpoint.');
    } finally {
      setIsAiLoading(false);
    }
  };

  // Color Role labels according to 60-30-10 principle
  const getRoleLabel = (index: number, total: number) => {
    if (total === 4) {
      if (index === 0) return 'Dominant Surface (60%)';
      if (index === 1) return 'Secondary Card (30%)';
      if (index === 2) return 'Accent CTA (10%)';
      return 'Highlight / Text';
    }
    if (total === 3) {
      if (index === 0) return 'Dominant (60%)';
      if (index === 1) return 'Secondary (30%)';
      return 'Accent (10%)';
    }
    return index === 0 ? 'Primary' : 'Partner Hue';
  };

  return (
    <div className="flex flex-col gap-6 max-w-4xl mx-auto w-full pb-20">
      
      {/* Top Controls: Preset selector & Action bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900/80 p-3.5 rounded-2xl border border-slate-800">
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-slate-300">Preset Combos:</span>
          <select
            onChange={(e) => {
              const found = PRESET_COMBOS.find((p) => p.name === e.target.value);
              if (found) {
                setColors(found.colors);
                setAiCritique(null);
              }
            }}
            className="bg-slate-950 border border-slate-700 text-xs text-slate-200 rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-indigo-500 font-medium"
            defaultValue=""
          >
            <option value="" disabled>Select test combination...</option>
            {PRESET_COMBOS.map((p) => (
              <option key={p.name} value={p.name}>
                {p.name} ({p.category})
              </option>
            ))}
          </select>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleRandomize}
            className="min-h-[44px] px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded-xl flex items-center gap-1.5 transition-colors border border-slate-700"
            title="Randomize colors to test wild combos"
          >
            <Shuffle className="w-3.5 h-3.5" />
            <span>Randomize</span>
          </button>

          <button
            type="button"
            onClick={handleHarmonize}
            className="min-h-[44px] px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-all shadow-md shadow-indigo-600/20 active:scale-95"
            title="Automatically tune hues and lightness to optimal harmony"
          >
            <Wand2 className="w-3.5 h-3.5" />
            <span>1-Tap Harmonize</span>
          </button>
        </div>
      </div>

      {/* The 4-Color Input Slots */}
      <div className="flex flex-col gap-2">
        <div className="flex items-center justify-between text-xs text-slate-400 px-1">
          <span>Palette Slots ({colors.length}/4) — Tap any slot to edit via color picker</span>
          {colors.length < 4 && (
            <button
              type="button"
              onClick={handleAddColor}
              className="min-h-[44px] text-xs font-medium text-indigo-400 hover:text-indigo-300 flex items-center gap-1"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add 4th Color</span>
            </button>
          )}
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {displayedColors.map((hex, index) => {
            const rawHex = colors[index];
            const hsl = hexToHsl(rawHex);
            const isSelected = selectedColorIndex === index;
            const role = getRoleLabel(index, colors.length);

            return (
              <div
                key={`color-slot-${index}`}
                onClick={() => {
                  setSelectedColorIndex(index);
                  setIsPickerOpen(true);
                }}
                className={`group relative p-3 rounded-2xl border cursor-pointer transition-all ${
                  isSelected
                    ? 'border-indigo-500 bg-slate-800/90 ring-2 ring-indigo-500/20 shadow-lg'
                    : 'border-slate-800 bg-slate-900/60 hover:border-slate-700 hover:bg-slate-850'
                }`}
              >
                {/* Visual Swatch */}
                <div
                  className="w-full h-16 rounded-xl border border-white/10 shadow-inner flex items-center justify-center relative overflow-hidden transition-colors"
                  style={{ backgroundColor: hex }}
                >
                  <span
                    className={`text-xs font-mono font-bold px-2 py-0.5 rounded backdrop-blur-sm ${
                      hsl.l > 55 ? 'text-slate-900 bg-white/70' : 'text-white bg-black/40'
                    }`}
                  >
                    {hex}
                  </span>

                  {colors.length > 2 && (
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleRemoveColor(index);
                      }}
                      className="absolute top-1.5 right-1.5 p-1 rounded-md bg-black/40 text-slate-300 hover:text-red-400 hover:bg-black/70 opacity-0 group-hover:opacity-100 transition-opacity"
                      title="Remove color slot"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  )}
                </div>

                {/* Metadata & Role */}
                <div className="mt-2.5 flex flex-col gap-0.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-semibold text-slate-200">
                      Color {index + 1}
                    </span>
                    <span className="text-[10px] font-mono text-slate-400">
                      {hsl.h}° / {hsl.l}%L
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-400 truncate">
                    {role}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Main Interactive Studio Area: Wheel & Diagnostic Verdict */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left Column: Interactive 360° Color Wheel */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 p-5 rounded-3xl shadow-xl flex flex-col items-center">
          <div className="w-full flex items-center justify-between mb-2">
            <h3 className="text-sm font-bold text-slate-100">Wheel Harmony Angles</h3>
            <span className="text-xs font-medium text-indigo-400 font-mono">
              {harmony.type}
            </span>
          </div>

          <ColorWheel
            colors={colors}
            selectedIndex={selectedColorIndex}
            onSelectColorIndex={(i) => {
              setSelectedColorIndex(i);
            }}
            onChangeColor={handleColorChange}
            harmonyType={harmony.type}
            size={260}
          />

          <div className="w-full mt-4 p-3 bg-slate-950 rounded-xl border border-slate-800/80 flex flex-col gap-1.5">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400">Wheel Alignment:</span>
              <span className="font-semibold text-slate-200">{harmony.confidence}% Match</span>
            </div>
            <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-indigo-500 to-emerald-400 transition-all duration-300"
                style={{ width: `${harmony.confidence}%` }}
              />
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed mt-1">
              {harmony.description}
            </p>
          </div>
        </div>

        {/* Right Column: In-Depth Diagnostic & Verdict */}
        <div className="lg:col-span-7 flex flex-col gap-4">
          
          {/* Aesthetic Pleasingness Score Card */}
          <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl shadow-xl flex flex-col gap-4">
            
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                  Perceptual Aesthetic Analysis
                </span>
                <h3 className="text-lg font-bold text-slate-100 mt-0.5">
                  {aesthetic.ratingText}
                </h3>
              </div>

              {/* Circular Score Badge */}
              <div className="flex items-center gap-2">
                <div
                  className={`w-14 h-14 rounded-2xl flex flex-col items-center justify-center font-bold font-mono border ${
                    aesthetic.overallScore >= 80
                      ? 'bg-emerald-950/60 border-emerald-500/50 text-emerald-300'
                      : aesthetic.overallScore >= 60
                      ? 'bg-amber-950/60 border-amber-500/50 text-amber-300'
                      : 'bg-rose-950/60 border-rose-500/50 text-rose-300'
                  }`}
                >
                  <span className="text-xl leading-none">{aesthetic.overallScore}</span>
                  <span className="text-[9px] font-normal uppercase opacity-75">/ 100</span>
                </div>
              </div>
            </div>

            {/* Why Explanation (The core user question: "Is it pleasing and WHY?") */}
            <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800/80 flex flex-col gap-2">
              <div className="flex items-center gap-2 text-xs font-bold text-slate-200">
                <Info className="w-4 h-4 text-indigo-400" />
                <span>Why this combination {aesthetic.overallScore >= 70 ? 'works' : 'struggles'}:</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                {aesthetic.whyExplanation}
              </p>
            </div>

            {/* Sub-Metrics Breakdown Bar */}
            <div className="grid grid-cols-3 gap-2">
              <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800/70 flex flex-col">
                <span className="text-[10px] text-slate-400">Harmony Geometry</span>
                <span className="text-sm font-bold font-mono text-slate-200 mt-1">
                  {aesthetic.harmonyScore}%
                </span>
              </div>
              <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800/70 flex flex-col">
                <span className="text-[10px] text-slate-400">Value Contrast</span>
                <span className="text-sm font-bold font-mono text-slate-200 mt-1">
                  {aesthetic.luminanceSpreadScore}%
                </span>
              </div>
              <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800/70 flex flex-col">
                <span className="text-[10px] text-slate-400">Saturation Rhythm</span>
                <span className="text-sm font-bold font-mono text-slate-200 mt-1">
                  {aesthetic.saturationBalanceScore}%
                </span>
              </div>
            </div>

            {/* Vibration Warning Alert if present */}
            {aesthetic.vibrationWarning && (
              <div className="bg-rose-950/40 border border-rose-600/40 p-3.5 rounded-2xl flex items-start gap-2.5 text-rose-200">
                <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <div className="flex flex-col gap-1 text-xs">
                  <span className="font-bold text-rose-300">
                    Optical Vibration Detected!
                  </span>
                  <p className="text-rose-200/90 leading-relaxed">
                    Two intensely saturated colors meet at near-identical luminance (
                    {aesthetic.vibrationPair?.join(' & ')}). Human eye cones cannot lock focus, creating visual fluttering along their edges.
                  </p>
                </div>
              </div>
            )}

            {/* Strengths & Actionable Suggestions */}
            <div className="flex flex-col gap-2.5 text-xs">
              {aesthetic.strengths.length > 0 && (
                <div className="flex flex-col gap-1">
                  <span className="text-[11px] font-semibold text-emerald-400 flex items-center gap-1.5">
                    <CheckCircle className="w-3.5 h-3.5" /> Strengths
                  </span>
                  <ul className="list-disc list-inside text-slate-300 space-y-0.5 pl-1">
                    {aesthetic.strengths.map((s, idx) => (
                      <li key={`str-${idx}`}>{s}</li>
                    ))}
                  </ul>
                </div>
              )}

              {aesthetic.actionableSuggestions.length > 0 && (
                <div className="flex flex-col gap-1 pt-1 border-t border-slate-800">
                  <span className="text-[11px] font-semibold text-amber-400 flex items-center gap-1.5">
                    <Wand2 className="w-3.5 h-3.5" /> How to Polish This Combo
                  </span>
                  <ul className="list-disc list-inside text-slate-300 space-y-0.5 pl-1">
                    {aesthetic.actionableSuggestions.map((s, idx) => (
                      <li key={`act-${idx}`}>{s}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

          </div>

          {/* AI Colorist Critique Section */}
          <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs font-bold text-slate-200">
                <Bot className="w-4 h-4 text-indigo-400" />
                <span>AI Art Director Critique (Gemini)</span>
              </div>
              <button
                type="button"
                onClick={handleRequestAiCritique}
                disabled={isAiLoading}
                className="min-h-[44px] px-3 py-1 bg-indigo-600/30 hover:bg-indigo-600/50 text-indigo-200 border border-indigo-500/30 text-xs font-medium rounded-xl flex items-center gap-1.5 transition-colors disabled:opacity-50"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>{isAiLoading ? 'Analyzing...' : 'Get Deep Critique'}</span>
              </button>
            </div>

            {aiCritique && (
              <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 text-xs text-slate-300 whitespace-pre-line leading-relaxed">
                {aiCritique}
              </div>
            )}
          </div>

        </div>
      </div>

      {/* Secondary Tabs: WCAG Accessibility Matrix & Android UI Simulator */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl flex flex-col gap-5">
        
        {/* Navigation Tabs */}
        <div className="flex items-center gap-1 p-1 bg-slate-950 rounded-xl border border-slate-800 self-start">
          <button
            type="button"
            onClick={() => setActiveTab('analysis')}
            className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors min-h-[44px] flex items-center gap-2 ${
              activeTab === 'analysis'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Contrast & WCAG Matrix</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('accessibility')}
            className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors min-h-[44px] flex items-center gap-2 ${
              activeTab === 'accessibility'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Eye className="w-3.5 h-3.5" />
            <span>Vision Simulation</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('preview')}
            className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors min-h-[44px] flex items-center gap-2 ${
              activeTab === 'preview'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>Android App Mockup</span>
          </button>
        </div>

        {/* Tab 1: WCAG 2.1 Contrast Matrix */}
        {activeTab === 'analysis' && (
          <div className="flex flex-col gap-4">
            <div>
              <h4 className="text-sm font-bold text-slate-100">WCAG 2.1 Contrast Ratios</h4>
              <p className="text-xs text-slate-400 mt-0.5">
                Evaluates text legibility between all pairs. Requires &ge; 4.5:1 for body text (AA) and &ge; 3.0:1 for large headlines.
              </p>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400 font-medium">
                    <th className="py-2.5 px-3">Foreground</th>
                    <th className="py-2.5 px-3">Background</th>
                    <th className="py-2.5 px-3">Contrast</th>
                    <th className="py-2.5 px-3">Normal Text (AA)</th>
                    <th className="py-2.5 px-3">Large Text (AA)</th>
                    <th className="py-2.5 px-3">Preview</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-mono">
                  {colors.flatMap((fg, i) =>
                    colors
                      .filter((_, j) => i !== j)
                      .slice(0, 4)
                      .map((bg, j) => {
                        const check = checkWcag(fg, bg);
                        return (
                          <tr key={`contrast-${i}-${j}`} className="hover:bg-slate-850">
                            <td className="py-2 px-3">
                              <div className="flex items-center gap-2">
                                <span
                                  className="w-3.5 h-3.5 rounded-full border border-white/20"
                                  style={{ backgroundColor: fg }}
                                />
                                <span className="text-slate-300">{fg}</span>
                              </div>
                            </td>
                            <td className="py-2 px-3">
                              <div className="flex items-center gap-2">
                                <span
                                  className="w-3.5 h-3.5 rounded-full border border-white/20"
                                  style={{ backgroundColor: bg }}
                                />
                                <span className="text-slate-300">{bg}</span>
                              </div>
                            </td>
                            <td className="py-2 px-3 font-bold text-slate-100">
                              {check.ratio}:1
                            </td>
                            <td className="py-2 px-3">
                              {check.aaNormal ? (
                                <span className="text-emerald-400 font-semibold">Pass (AA)</span>
                              ) : (
                                <span className="text-rose-400/80 font-normal">Fail</span>
                              )}
                            </td>
                            <td className="py-2 px-3">
                              {check.aaLarge ? (
                                <span className="text-emerald-400 font-semibold">Pass (AA)</span>
                              ) : (
                                <span className="text-rose-400/80 font-normal">Fail</span>
                              )}
                            </td>
                            <td className="py-2 px-3">
                              <div
                                className="px-2.5 py-1 rounded text-[11px] font-sans font-semibold text-center border border-white/10"
                                style={{ backgroundColor: bg, color: fg }}
                              >
                                Sample Text
                              </div>
                            </td>
                          </tr>
                        );
                      })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Tab 2: Color Blindness Vision Simulation */}
        {activeTab === 'accessibility' && (
          <div className="flex flex-col gap-4">
            <div>
              <h4 className="text-sm font-bold text-slate-100">Color Blindness Simulator</h4>
              <p className="text-xs text-slate-400 mt-0.5">
                Preview how users with common color vision deficiencies perceive your combination.
              </p>
            </div>

            <div className="flex flex-wrap gap-2">
              {(
                [
                  ['normal', 'Normal Vision'],
                  ['protanopia', 'Protanopia (Red-blind)'],
                  ['deuteranopia', 'Deuteranopia (Green-blind)'],
                  ['tritanopia', 'Tritanopia (Blue-blind)'],
                  ['achromatopsia', 'Achromatopsia (Grayscale)'],
                ] as const
              ).map(([type, label]) => (
                <button
                  key={type}
                  type="button"
                  onClick={() => setActiveBlindness(type)}
                  className={`min-h-[44px] px-3.5 py-2 text-xs font-semibold rounded-xl border transition-colors ${
                    activeBlindness === type
                      ? 'bg-indigo-600 text-white border-indigo-500 shadow-md'
                      : 'bg-slate-950 text-slate-300 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-2">
              {displayedColors.map((simHex, i) => (
                <div
                  key={`sim-${i}`}
                  className="p-3 bg-slate-950 rounded-2xl border border-slate-800 flex flex-col gap-2"
                >
                  <div
                    className="w-full h-16 rounded-xl border border-white/10"
                    style={{ backgroundColor: simHex }}
                  />
                  <div className="flex justify-between text-xs font-mono">
                    <span className="text-slate-400">Color {i + 1}</span>
                    <span className="text-slate-200">{simHex}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab 3: Live Android Mockup */}
        {activeTab === 'preview' && (
          <div className="flex flex-col items-center">
            <AndroidUiPreview colors={displayedColors} />
          </div>
        )}

      </div>

      {/* Color Picker Drawer */}
      <ColorPickerDrawer
        isOpen={isPickerOpen}
        onClose={() => setIsPickerOpen(false)}
        currentColor={colors[selectedColorIndex] || '#3B82F6'}
        onApplyColor={(newColor) => handleColorChange(selectedColorIndex, newColor)}
        colorIndex={selectedColorIndex}
      />
    </div>
  );
};
