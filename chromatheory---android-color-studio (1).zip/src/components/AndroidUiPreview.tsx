import React from 'react';
import { Wifi, Battery, Signal, Bell, ArrowRight, Heart, Sparkles, CheckCircle2 } from 'lucide-react';
import { hexToHsl, getContrastRatio } from '../utils/colorMath';

interface AndroidUiPreviewProps {
  colors: string[];
}

export const AndroidUiPreview: React.FC<AndroidUiPreviewProps> = ({ colors }) => {
  // Safe color fallbacks for slots
  const c1 = colors[0] || '#1E293B'; // 60% Dominant (Surfaces/Background)
  const c2 = colors[1] || '#3B82F6'; // 30% Secondary (Cards/App Bar)
  const c3 = colors[2] || '#F59E0B'; // 10% Accent (CTA/Badges)
  const c4 = colors[3] || '#F8FAFC'; // Supporting/Surface

  const hsl1 = hexToHsl(c1);
  const hsl2 = hexToHsl(c2);
  const hsl3 = hexToHsl(c3);
  const hsl4 = hexToHsl(c4);

  // Dynamic text color based on background lightness
  const textOnC1 = hsl1.l > 60 ? '#0f172a' : '#f8fafc';
  const textOnC2 = hsl2.l > 60 ? '#0f172a' : '#f8fafc';
  const textOnC3 = hsl3.l > 60 ? '#0f172a' : '#f8fafc';
  const textOnC4 = hsl4.l > 60 ? '#0f172a' : '#f8fafc';

  const contrastC3onC1 = getContrastRatio(c3, c1).toFixed(1);

  return (
    <div className="w-full flex flex-col items-center">
      {/* Smartphone Shell Preview */}
      <div
        className="w-full max-w-[340px] rounded-3xl overflow-hidden border-4 border-slate-700 shadow-2xl transition-colors duration-300 flex flex-col"
        style={{ backgroundColor: c1, color: textOnC1 }}
      >
        {/* Android Status Bar */}
        <div className="flex items-center justify-between px-5 pt-3 pb-2 text-[11px] font-mono opacity-80">
          <span>09:41</span>
          <div className="flex items-center gap-1.5">
            <Signal className="w-3.5 h-3.5" />
            <Wifi className="w-3.5 h-3.5" />
            <Battery className="w-3.5 h-3.5" />
          </div>
        </div>

        {/* Android App Top Bar */}
        <div
          className="px-5 py-3.5 flex items-center justify-between border-b transition-colors shadow-sm"
          style={{
            backgroundColor: c2,
            color: textOnC2,
            borderColor: 'rgba(255, 255, 255, 0.1)',
          }}
        >
          <div className="flex items-center gap-2">
            <div
              className="w-7 h-7 rounded-full flex items-center justify-center font-bold text-xs"
              style={{ backgroundColor: c3, color: textOnC3 }}
            >
              C
            </div>
            <span className="font-bold text-sm tracking-tight">Pixel ColorStudio</span>
          </div>
          <Bell className="w-4 h-4 opacity-75" />
        </div>

        {/* Scrollable Screen Content */}
        <div className="p-4 flex flex-col gap-3">
          
          {/* Hero Feature Card */}
          <div
            className="p-4 rounded-2xl shadow-md transition-all flex flex-col gap-2.5"
            style={{
              backgroundColor: c2,
              color: textOnC2,
            }}
          >
            <div className="flex items-center justify-between">
              <span
                className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full"
                style={{ backgroundColor: c3, color: textOnC3 }}
              >
                60-30-10 Harmony
              </span>
              <Sparkles className="w-4 h-4 opacity-80" />
            </div>

            <div>
              <h4 className="text-base font-bold leading-tight">Harmonic Layout</h4>
              <p className="text-xs opacity-85 mt-1 leading-relaxed">
                Notice how your secondary and accent colors establish natural visual hierarchy against the dominant canvas.
              </p>
            </div>

            <button
              type="button"
              className="mt-1 w-full py-2.5 px-4 rounded-xl font-bold text-xs flex items-center justify-center gap-2 shadow-sm transition-transform active:scale-95"
              style={{
                backgroundColor: c3,
                color: textOnC3,
              }}
            >
              <span>Explore Collection</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Quick Metrics / Category Cards */}
          <div className="grid grid-cols-2 gap-2.5">
            <div
              className="p-3 rounded-xl border transition-colors flex flex-col justify-between h-20"
              style={{
                backgroundColor: c4,
                color: textOnC4,
                borderColor: 'rgba(255, 255, 255, 0.15)',
              }}
            >
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-medium opacity-75">Contrast Ratio</span>
                <CheckCircle2 className="w-3.5 h-3.5" style={{ color: c3 }} />
              </div>
              <span className="text-lg font-mono font-bold">{contrastC3onC1}:1</span>
            </div>

            <div
              className="p-3 rounded-xl border transition-colors flex flex-col justify-between h-20"
              style={{
                backgroundColor: c2,
                color: textOnC2,
                borderColor: 'rgba(255, 255, 255, 0.15)',
              }}
            >
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-medium opacity-75">Saved Palettes</span>
                <Heart className="w-3.5 h-3.5 opacity-80" />
              </div>
              <span className="text-lg font-mono font-bold">12 Sets</span>
            </div>
          </div>

          {/* List Item Sample */}
          <div
            className="p-3 rounded-xl flex items-center justify-between border"
            style={{
              backgroundColor: 'rgba(255, 255, 255, 0.05)',
              borderColor: 'rgba(255, 255, 255, 0.1)',
            }}
          >
            <div className="flex items-center gap-2.5">
              <div
                className="w-3.5 h-3.5 rounded-full"
                style={{ backgroundColor: c3 }}
              />
              <span className="text-xs font-medium">Jetpack Compose Ready</span>
            </div>
            <span className="text-[10px] font-mono opacity-70">v2.4</span>
          </div>

        </div>

        {/* Android Gesture Navigation Bar */}
        <div className="py-2 flex justify-center opacity-40">
          <div
            className="w-24 h-1 rounded-full"
            style={{ backgroundColor: textOnC1 }}
          />
        </div>
      </div>

      <div className="mt-2 text-center text-[11px] text-slate-400">
        Live Android Material 3 Preview
      </div>
    </div>
  );
};
