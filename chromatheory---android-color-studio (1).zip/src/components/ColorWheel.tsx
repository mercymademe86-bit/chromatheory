import React, { useRef, useEffect, useState, useCallback } from 'react';
import { hexToHsl, hslToHex, hueDistance } from '../utils/colorMath';

interface ColorWheelProps {
  colors: string[];
  selectedIndex: number;
  onSelectColorIndex: (index: number) => void;
  onChangeColor: (index: number, newHex: string) => void;
  harmonyType?: string;
  size?: number;
}

export const ColorWheel: React.FC<ColorWheelProps> = ({
  colors,
  selectedIndex,
  onSelectColorIndex,
  onChangeColor,
  harmonyType,
  size = 280,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [isDragging, setIsDragging] = useState(false);

  const radius = size / 2;
  const innerRadius = radius * 0.28;
  const outerRadius = radius * 0.92;

  // Draw the HSL Color Wheel on Canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Handle high DPI
    const dpr = window.devicePixelRatio || 1;
    canvas.width = size * dpr;
    canvas.height = size * dpr;
    ctx.scale(dpr, dpr);

    ctx.clearRect(0, 0, size, size);

    // Draw circular color wheel ring
    const centerX = size / 2;
    const centerY = size / 2;

    const ringThickness = outerRadius - innerRadius;
    const step = 0.5; // half-degree resolution

    for (let angle = 0; angle < 360; angle += step) {
      const rad = ((angle - 90) * Math.PI) / 180;
      const nextRad = ((angle + step + 0.1 - 90) * Math.PI) / 180;

      // Draw radial slice with gradient from center saturation/lightness to outer
      const gradient = ctx.createRadialGradient(centerX, centerY, innerRadius, centerX, centerY, outerRadius);
      gradient.addColorStop(0, `hsl(${angle}, 20%, 85%)`);
      gradient.addColorStop(0.7, `hsl(${angle}, 85%, 52%)`);
      gradient.addColorStop(1, `hsl(${angle}, 95%, 45%)`);

      ctx.beginPath();
      ctx.moveTo(centerX + innerRadius * Math.cos(rad), centerY + innerRadius * Math.sin(rad));
      ctx.lineTo(centerX + outerRadius * Math.cos(rad), centerY + outerRadius * Math.sin(rad));
      ctx.lineTo(centerX + outerRadius * Math.cos(nextRad), centerY + outerRadius * Math.sin(nextRad));
      ctx.lineTo(centerX + innerRadius * Math.cos(nextRad), centerY + innerRadius * Math.sin(nextRad));
      ctx.closePath();

      ctx.fillStyle = gradient;
      ctx.fill();
    }

    // Draw dark inner cutout
    ctx.beginPath();
    ctx.arc(centerX, centerY, innerRadius - 1, 0, Math.PI * 2);
    ctx.fillStyle = '#0f172a'; // slate-900 background
    ctx.fill();
    ctx.strokeStyle = '#334155';
    ctx.lineWidth = 1;
    ctx.stroke();

    // Draw outer border
    ctx.beginPath();
    ctx.arc(centerX, centerY, outerRadius + 1, 0, Math.PI * 2);
    ctx.strokeStyle = '#334155';
    ctx.lineWidth = 1.5;
    ctx.stroke();

    // Draw subtle 30-degree spoke guidelines
    for (let deg = 0; deg < 360; deg += 30) {
      const rad = ((deg - 90) * Math.PI) / 180;
      ctx.beginPath();
      ctx.moveTo(centerX + (innerRadius + 2) * Math.cos(rad), centerY + (innerRadius + 2) * Math.sin(rad));
      ctx.lineTo(centerX + (outerRadius - 2) * Math.cos(rad), centerY + (outerRadius - 2) * Math.sin(rad));
      ctx.strokeStyle = deg % 90 === 0 ? 'rgba(255, 255, 255, 0.25)' : 'rgba(255, 255, 255, 0.08)';
      ctx.lineWidth = deg % 90 === 0 ? 1.5 : 1;
      ctx.stroke();
    }

  }, [size, innerRadius, outerRadius]);

  // Calculate coordinates for a given color
  const getCoordinates = (hex: string) => {
    const hsl = hexToHsl(hex);
    const angleRad = ((hsl.h - 90) * Math.PI) / 180;
    // Map saturation to distance between inner and outer radius
    const dist = innerRadius + ((outerRadius - innerRadius) * Math.max(0.2, hsl.s / 100));
    return {
      x: size / 2 + dist * Math.cos(angleRad),
      y: size / 2 + dist * Math.sin(angleRad),
      hsl,
    };
  };

  const points = colors.map(getCoordinates);

  // Handle interaction (drag / click to update selected color's hue)
  const handlePointerAction = useCallback((clientX: number, clientY: number) => {
    if (selectedIndex < 0 || selectedIndex >= colors.length) return;
    const container = containerRef.current;
    if (!container) return;

    const rect = container.getBoundingClientRect();
    const x = clientX - rect.left - size / 2;
    const y = clientY - rect.top - size / 2;

    // Calculate angle in degrees (0 - 360)
    let angle = (Math.atan2(y, x) * 180) / Math.PI + 90;
    if (angle < 0) angle += 360;
    angle = Math.round(angle) % 360;

    // Calculate distance to determine saturation
    const dist = Math.sqrt(x * x + y * y);
    const normalizedDist = Math.max(0, Math.min(1, (dist - innerRadius) / (outerRadius - innerRadius)));
    const newSat = Math.max(15, Math.min(100, Math.round(normalizedDist * 100)));

    const currentHsl = hexToHsl(colors[selectedIndex]);
    const newHex = hslToHex(angle, newSat, currentHsl.l);
    onChangeColor(selectedIndex, newHex);
  }, [selectedIndex, colors, onChangeColor, size, innerRadius, outerRadius]);

  const handlePointerDown = (e: React.PointerEvent) => {
    setIsDragging(true);
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
    handlePointerAction(e.clientX, e.clientY);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDragging) return;
    handlePointerAction(e.clientX, e.clientY);
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    setIsDragging(false);
    try {
      (e.target as HTMLElement).releasePointerCapture(e.pointerId);
    } catch {}
  };

  return (
    <div className="flex flex-col items-center">
      <div
        ref={containerRef}
        className="relative touch-none cursor-crosshair select-none rounded-full shadow-xl shadow-black/40"
        style={{ width: size, height: size }}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
      >
        <canvas
          ref={canvasRef}
          style={{ width: size, height: size }}
          className="rounded-full pointer-events-none"
        />

        {/* SVG Overlay for harmony geometric lines & angle indicators */}
        <svg
          className="absolute inset-0 pointer-events-none"
          width={size}
          height={size}
        >
          {/* Geometric connector lines between points */}
          {points.length > 1 && (
            <polygon
              points={points.map(p => `${p.x},${p.y}`).join(' ')}
              fill="rgba(99, 102, 241, 0.08)"
              stroke="rgba(255, 255, 255, 0.45)"
              strokeWidth="1.5"
              strokeDasharray="4 3"
            />
          )}

          {/* Lines from center to active points */}
          {points.map((p, i) => (
            <line
              key={`line-${i}`}
              x1={size / 2}
              y1={size / 2}
              x2={p.x}
              y2={p.y}
              stroke={i === selectedIndex ? '#ffffff' : 'rgba(255, 255, 255, 0.25)'}
              strokeWidth={i === selectedIndex ? 1.5 : 1}
            />
          ))}
        </svg>

        {/* Central Hub Display */}
        <div
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 flex flex-col items-center justify-center pointer-events-none text-center"
          style={{ width: innerRadius * 2, height: innerRadius * 2 }}
        >
          <span className="text-[10px] tracking-wider uppercase text-slate-400 font-medium">
            {harmonyType || 'Harmony'}
          </span>
          <span className="text-xs font-mono font-bold text-slate-100">
            {colors[selectedIndex] ? `${hexToHsl(colors[selectedIndex]).h}°` : '360°'}
          </span>
        </div>

        {/* Interactive draggable Color Pins */}
        {points.map((p, i) => {
          const isSelected = i === selectedIndex;
          const isSelectedColor = colors[i];
          return (
            <button
              key={`pin-${i}`}
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onSelectColorIndex(i);
              }}
              style={{
                left: `${p.x}px`,
                top: `${p.y}px`,
                backgroundColor: isSelectedColor,
              }}
              className={`absolute -translate-x-1/2 -translate-y-1/2 rounded-full transition-transform duration-100 shadow-md ${
                isSelected
                  ? 'w-7 h-7 ring-3 ring-white ring-offset-2 ring-offset-slate-900 scale-110 z-20 shadow-lg'
                  : 'w-5 h-5 ring-2 ring-slate-900 hover:scale-105 z-10'
              }`}
              title={`Color ${i + 1}: ${isSelectedColor} (${p.hsl.h}°, Sat ${p.hsl.s}%, Lum ${p.hsl.l}%)`}
            >
              <span className={`text-[10px] font-bold ${p.hsl.l > 55 ? 'text-slate-950' : 'text-white'}`}>
                {i + 1}
              </span>
            </button>
          );
        })}
      </div>

      <div className="mt-3 flex items-center gap-2 text-xs text-slate-400">
        <span>Touch or drag pins to adjust hues</span>
        <span aria-hidden="true">·</span>
        <span className="font-mono text-slate-300">
          Color {selectedIndex + 1}: {colors[selectedIndex]} ({hexToHsl(colors[selectedIndex] || '#000000').h}°)
        </span>
      </div>
    </div>
  );
};
