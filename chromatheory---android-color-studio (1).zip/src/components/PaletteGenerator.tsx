import React, { useState } from 'react';
import {
  generateTheoryPalette,
  hexToHsl,
  hslToHex,
  rgbToHex,
  hexToRgb,
} from '../utils/colorMath';
import { ColorPickerDrawer } from './ColorPickerDrawer';
import {
  Palette,
  Wand2,
  Copy,
  Check,
  Bookmark,
  Shuffle,
  Code2,
  Sparkles,
  ArrowRight,
  SlidersHorizontal,
} from 'lucide-react';

interface PaletteGeneratorProps {
  onSendToAnalyzer: (colors: string[]) => void;
}

const HARMONY_MODELS = [
  { id: 'Complementary', label: 'Complementary (180°)', desc: 'High contrast opposite pair with supporting tints' },
  { id: 'Triadic', label: 'Triadic (120°)', desc: 'Equilateral chromatic triad with balanced energy' },
  { id: 'Split-Complementary', label: 'Split-Complementary (150°/210°)', desc: 'Subtle high contrast with reduced tension' },
  { id: 'Analogous', label: 'Analogous (±30°)', desc: 'Adjacent peaceful harmonies and natural gradients' },
  { id: 'Tetradic', label: 'Tetradic / Rectangle', desc: 'Dual complementary rich palette' },
  { id: 'Square', label: 'Square (90°)', desc: 'Equidistant 4-corner bold balance' },
  { id: 'Monochromatic', label: 'Monochromatic', desc: 'Single hue value depth (tints and shades)' },
];

export const PaletteGenerator: React.FC<PaletteGeneratorProps> = ({ onSendToAnalyzer }) => {
  const [baseColor, setBaseColor] = useState<string>('#3B82F6');
  const [selectedHarmony, setSelectedHarmony] = useState<string>('Complementary');
  const [copiedFormat, setCopiedFormat] = useState<string | null>(null);
  const [isPickerOpen, setIsPickerOpen] = useState(false);
  const [savedPalettes, setSavedPalettes] = useState<Array<{ name: string; colors: string[] }>>(() => {
    try {
      const stored = localStorage.getItem('chroma_saved_palettes');
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  // Generate palette according to theoretical model
  const generatedColors = generateTheoryPalette(baseColor, selectedHarmony);

  const handleRandomizeBase = () => {
    const randomHex =
      '#' + Math.floor(Math.random() * 16777215).toString(16).padStart(6, '0').toUpperCase();
    setBaseColor(randomHex);
  };

  const handleSavePalette = () => {
    const newEntry = {
      name: `${selectedHarmony} ${baseColor}`,
      colors: generatedColors,
    };
    const updated = [newEntry, ...savedPalettes.slice(0, 19)];
    setSavedPalettes(updated);
    try {
      localStorage.setItem('chroma_saved_palettes', JSON.stringify(updated));
    } catch {}
  };

  const copyToClipboard = (text: string, formatName: string) => {
    navigator.clipboard.writeText(text);
    setCopiedFormat(formatName);
    setTimeout(() => setCopiedFormat(null), 2000);
  };

  // Generate Jetpack Compose Kotlin Code
  const getJetpackComposeCode = () => {
    const colorLines = generatedColors.map((hex, i) => {
      const clean = hex.replace('#', '').toUpperCase();
      return `val Color${i + 1} = Color(0xFF${clean})`;
    });
    return `// Android Jetpack Compose Palette\nimport androidx.compose.ui.graphics.Color\n\n${colorLines.join('\n')}`;
  };

  // Generate Android XML Colors Code
  const getAndroidXmlCode = () => {
    const colorTags = generatedColors.map((hex, i) => {
      return `    <color name="palette_color_${i + 1}">${hex}</color>`;
    });
    return `<!-- res/values/colors.xml -->\n<resources>\n${colorTags.join('\n')}\n</resources>`;
  };

  // Generate CSS Variables Code
  const getCssVarsCode = () => {
    const lines = generatedColors.map((hex, i) => `  --color-${i + 1}: ${hex};`);
    return `:root {\n${lines.join('\n')}\n}`;
  };

  return (
    <div className="flex flex-col gap-6 max-w-4xl mx-auto w-full pb-20">
      
      {/* Hero Header */}
      <div className="bg-slate-900 border border-slate-800 p-6 rounded-3xl shadow-xl flex flex-col gap-2">
        <div className="flex items-center gap-2 text-xs font-semibold text-indigo-400">
          <Palette className="w-4 h-4" />
          <span>Theory Studio</span>
        </div>
        <h2 className="text-xl font-bold text-slate-100">Harmonic Palette Designer</h2>
        <p className="text-xs text-slate-300 leading-relaxed max-w-2xl">
          Anchor a base hue and choose a mathematical harmony rule to generate balanced, accessible palettes for Android apps and design systems.
        </p>
      </div>

      {/* Generator Controls */}
      <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl shadow-xl flex flex-col gap-5">
        
        {/* Base Anchor Color Selector */}
        <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setIsPickerOpen(true)}
              className="w-12 h-12 rounded-2xl border-2 border-white/20 shadow-md flex items-center justify-center transition-transform active:scale-95"
              style={{ backgroundColor: baseColor }}
              title="Click to edit base anchor color"
            />
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                Base Anchor Color
              </span>
              <div className="flex items-center gap-2 mt-0.5">
                <span className="text-sm font-mono font-bold text-slate-100">
                  {baseColor}
                </span>
                <span className="text-xs text-slate-400 font-mono">
                  ({hexToHsl(baseColor).h}° Hue)
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleRandomizeBase}
              className="min-h-[44px] px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors border border-slate-700"
            >
              <Shuffle className="w-3.5 h-3.5" />
              <span>Random Anchor</span>
            </button>
            <button
              type="button"
              onClick={() => setIsPickerOpen(true)}
              className="min-h-[44px] px-3.5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-all shadow-md shadow-indigo-600/20 active:scale-95"
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              <span>Fine-Tune Hue</span>
            </button>
          </div>
        </div>

        {/* Harmony Model Selector */}
        <div className="flex flex-col gap-2">
          <span className="text-xs font-bold text-slate-300">
            Select Harmony Rule:
          </span>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2">
            {HARMONY_MODELS.map((model) => (
              <button
                key={model.id}
                type="button"
                onClick={() => setSelectedHarmony(model.id)}
                className={`min-h-[44px] p-2.5 rounded-xl border text-left flex flex-col justify-between transition-all ${
                  selectedHarmony === model.id
                    ? 'bg-indigo-600 text-white border-indigo-400 shadow-md shadow-indigo-600/20'
                    : 'bg-slate-950 text-slate-300 border-slate-800 hover:border-slate-700 hover:bg-slate-850'
                }`}
              >
                <span className="text-xs font-bold leading-tight">{model.label}</span>
                <span
                  className={`text-[10px] mt-1 leading-snug truncate ${
                    selectedHarmony === model.id ? 'text-indigo-100' : 'text-slate-400'
                  }`}
                >
                  {model.desc}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Live Generated Swatches Presentation */}
        <div className="flex flex-col gap-2 pt-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Resulting Harmonic Palette</span>
            <span className="font-mono">{generatedColors.length} Tones</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {generatedColors.map((hex, i) => {
              const hsl = hexToHsl(hex);
              return (
                <div
                  key={`gen-color-${i}`}
                  className="p-3 bg-slate-950 rounded-2xl border border-slate-800/80 flex flex-col gap-2"
                >
                  <div
                    className="w-full h-20 rounded-xl border border-white/10 shadow-inner flex items-center justify-center"
                    style={{ backgroundColor: hex }}
                  >
                    <span
                      className={`text-xs font-mono font-bold px-2 py-0.5 rounded backdrop-blur-sm ${
                        hsl.l > 55 ? 'text-slate-900 bg-white/70' : 'text-white bg-black/40'
                      }`}
                    >
                      {hex}
                    </span>
                  </div>

                  <div className="flex flex-col gap-0.5 text-xs">
                    <span className="font-semibold text-slate-200">
                      Tone {i + 1}
                    </span>
                    <span className="text-[11px] font-mono text-slate-400">
                      {hsl.h}° / {hsl.s}%S / {hsl.l}%L
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Actions Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-800">
          <button
            type="button"
            onClick={handleSavePalette}
            className="min-h-[44px] px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors border border-slate-700"
          >
            <Bookmark className="w-3.5 h-3.5 text-amber-400" />
            <span>Save to Library</span>
          </button>

          <button
            type="button"
            onClick={() => onSendToAnalyzer(generatedColors)}
            className="min-h-[44px] px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-xl flex items-center gap-2 transition-all shadow-md shadow-indigo-600/20 active:scale-95"
          >
            <span>Analyze in Combination Studio</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

      </div>

      {/* Code Export Drawer (Android Jetpack Compose, XML, CSS) */}
      <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl shadow-xl flex flex-col gap-4">
        <div className="flex items-center gap-2">
          <Code2 className="w-4 h-4 text-indigo-400" />
          <h3 className="text-sm font-bold text-slate-100">Android & Web Developer Export</h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {/* Jetpack Compose */}
          <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 flex flex-col justify-between gap-3">
            <div>
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-200">Jetpack Compose (Kotlin)</span>
                <span className="text-[10px] text-slate-400 font-mono">.kt</span>
              </div>
              <pre className="mt-2 text-[11px] font-mono text-slate-300 bg-slate-900 p-2.5 rounded-lg overflow-x-auto max-h-28">
                {getJetpackComposeCode()}
              </pre>
            </div>
            <button
              type="button"
              onClick={() => copyToClipboard(getJetpackComposeCode(), 'compose')}
              className="min-h-[44px] w-full py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl flex items-center justify-center gap-1.5 transition-colors border border-slate-700"
            >
              {copiedFormat === 'compose' ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy Compose</span>
                </>
              )}
            </button>
          </div>

          {/* Android XML */}
          <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 flex flex-col justify-between gap-3">
            <div>
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-200">Android XML</span>
                <span className="text-[10px] text-slate-400 font-mono">colors.xml</span>
              </div>
              <pre className="mt-2 text-[11px] font-mono text-slate-300 bg-slate-900 p-2.5 rounded-lg overflow-x-auto max-h-28">
                {getAndroidXmlCode()}
              </pre>
            </div>
            <button
              type="button"
              onClick={() => copyToClipboard(getAndroidXmlCode(), 'xml')}
              className="min-h-[44px] w-full py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl flex items-center justify-center gap-1.5 transition-colors border border-slate-700"
            >
              {copiedFormat === 'xml' ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy XML</span>
                </>
              )}
            </button>
          </div>

          {/* CSS Variables */}
          <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 flex flex-col justify-between gap-3">
            <div>
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-200">CSS Custom Properties</span>
                <span className="text-[10px] text-slate-400 font-mono">:root</span>
              </div>
              <pre className="mt-2 text-[11px] font-mono text-slate-300 bg-slate-900 p-2.5 rounded-lg overflow-x-auto max-h-28">
                {getCssVarsCode()}
              </pre>
            </div>
            <button
              type="button"
              onClick={() => copyToClipboard(getCssVarsCode(), 'css')}
              className="min-h-[44px] w-full py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl flex items-center justify-center gap-1.5 transition-colors border border-slate-700"
            >
              {copiedFormat === 'css' ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy CSS</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Saved Palettes Library if any exist */}
      {savedPalettes.length > 0 && (
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl shadow-xl flex flex-col gap-3">
          <span className="text-xs font-bold text-slate-200">Saved Palettes</span>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {savedPalettes.map((item, idx) => (
              <div
                key={`saved-${idx}`}
                className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between"
              >
                <div className="flex items-center gap-2">
                  <div className="flex items-center gap-1">
                    {item.colors.map((c, i) => (
                      <span
                        key={`sc-${i}`}
                        className="w-4 h-4 rounded-full border border-white/20"
                        style={{ backgroundColor: c }}
                      />
                    ))}
                  </div>
                  <span className="text-xs font-medium text-slate-300 truncate max-w-[140px]">
                    {item.name}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => onSendToAnalyzer(item.colors)}
                  className="min-h-[44px] px-2.5 py-1 text-xs text-indigo-400 hover:text-indigo-300 font-semibold"
                >
                  Analyze
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Color Picker Drawer */}
      <ColorPickerDrawer
        isOpen={isPickerOpen}
        onClose={() => setIsPickerOpen(false)}
        currentColor={baseColor}
        onApplyColor={(hex) => setBaseColor(hex)}
        colorIndex={0}
      />
    </div>
  );
};
