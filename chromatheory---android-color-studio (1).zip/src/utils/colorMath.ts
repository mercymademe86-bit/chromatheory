/**
 * Complete Color Theory & Colorimetry Math Engine
 * Supports RGB, HSL, HSV, LAB, relative luminance, WCAG 2.1 contrast,
 * chromatic vibration detection, harmony classification, and aesthetic scoring.
 */

export interface HSL {
  h: number; // 0 - 360
  s: number; // 0 - 100
  l: number; // 0 - 100
}

export interface RGB {
  r: number; // 0 - 255
  g: number; // 0 - 255
  b: number; // 0 - 255
}

export interface HarmonyResult {
  type: 'Monochromatic' | 'Complementary' | 'Split-Complementary' | 'Analogous' | 'Triadic' | 'Tetradic' | 'Square' | 'Custom / Discordant';
  confidence: number; // 0 - 100%
  description: string;
  angleDeviations: number[];
  recommendation: string;
  isStandardHarmony: boolean;
}

export interface ContrastCheck {
  fgHex: string;
  bgHex: string;
  ratio: number;
  aaNormal: boolean;
  aaLarge: boolean;
  aaaNormal: boolean;
  aaaLarge: boolean;
}

export interface AestheticAnalysis {
  overallScore: number; // 0 - 100
  ratingText: 'Harmonious & Refined' | 'Balanced & Pleasing' | 'Vibrant with High Energy' | 'Slightly Tensioned' | 'Clashing / Fatiguing';
  harmonyScore: number;
  luminanceSpreadScore: number;
  saturationBalanceScore: number;
  temperatureBalance: 'Warm Dominant' | 'Cool Dominant' | 'Balanced Warm/Cool' | 'Neutral/Monochrome';
  vibrationWarning: boolean;
  vibrationPair?: [string, string];
  strengths: string[];
  weaknesses: string[];
  whyExplanation: string;
  actionableSuggestions: string[];
}

// Convert Hex to RGB
export function hexToRgb(hex: string): RGB {
  let clean = hex.replace('#', '').trim();
  if (clean.length === 3) {
    clean = clean.split('').map(c => c + c).join('');
  }
  if (clean.length !== 6) {
    return { r: 0, g: 0, b: 0 };
  }
  const num = parseInt(clean, 16);
  if (isNaN(num)) return { r: 0, g: 0, b: 0 };
  return {
    r: (num >> 16) & 255,
    g: (num >> 8) & 255,
    b: num & 255,
  };
}

// Convert RGB to Hex
export function rgbToHex(r: number, g: number, b: number): string {
  const clamp = (v: number) => Math.max(0, Math.min(255, Math.round(v)));
  const toHex = (v: number) => clamp(v).toString(16).padStart(2, '0');
  return `#${toHex(r)}${toHex(g)}${toHex(b)}`.toUpperCase();
}

// Convert RGB to HSL
export function rgbToHsl(r: number, g: number, b: number): HSL {
  r /= 255;
  g /= 255;
  b /= 255;
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  let h = 0;
  let s = 0;
  const l = (max + min) / 2;

  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r:
        h = (g - b) / d + (g < b ? 6 : 0);
        break;
      case g:
        h = (b - r) / d + 2;
        break;
      case b:
        h = (r - g) / d + 4;
        break;
    }
    h /= 6;
  }

  return {
    h: Math.round(h * 360),
    s: Math.round(s * 100),
    l: Math.round(l * 100),
  };
}

// Convert HSL to RGB
export function hslToRgb(h: number, s: number, l: number): RGB {
  h = ((h % 360) + 360) % 360;
  s = Math.max(0, Math.min(100, s)) / 100;
  l = Math.max(0, Math.min(100, l)) / 100;

  const c = (1 - Math.abs(2 * l - 1)) * s;
  const x = c * (1 - Math.abs(((h / 60) % 2) - 1));
  const m = l - c / 2;
  let r = 0, g = 0, b = 0;

  if (h >= 0 && h < 60) {
    r = c; g = x; b = 0;
  } else if (h >= 60 && h < 120) {
    r = x; g = c; b = 0;
  } else if (h >= 120 && h < 180) {
    r = 0; g = c; b = x;
  } else if (h >= 180 && h < 240) {
    r = 0; g = x; b = c;
  } else if (h >= 240 && h < 300) {
    r = x; g = 0; b = c;
  } else if (h >= 300 && h < 360) {
    r = c; g = 0; b = x;
  }

  return {
    r: Math.round((r + m) * 255),
    g: Math.round((g + m) * 255),
    b: Math.round((b + m) * 255),
  };
}

export function hexToHsl(hex: string): HSL {
  const rgb = hexToRgb(hex);
  return rgbToHsl(rgb.r, rgb.g, rgb.b);
}

export function hslToHex(h: number, s: number, l: number): string {
  const rgb = hslToRgb(h, s, l);
  return rgbToHex(rgb.r, rgb.g, rgb.b);
}

// WCAG 2.1 Relative Luminance
export function getRelativeLuminance(rgb: RGB): number {
  const a = [rgb.r, rgb.g, rgb.b].map(v => {
    v /= 255;
    return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
  });
  return 0.2126 * a[0] + 0.7152 * a[1] + 0.0722 * a[2];
}

// Contrast Ratio between two colors
export function getContrastRatio(hex1: string, hex2: string): number {
  const l1 = getRelativeLuminance(hexToRgb(hex1));
  const l2 = getRelativeLuminance(hexToRgb(hex2));
  const lighter = Math.max(l1, l2);
  const darker = Math.min(l1, l2);
  return (lighter + 0.05) / (darker + 0.05);
}

// Check WCAG compliance
export function checkWcag(fgHex: string, bgHex: string): ContrastCheck {
  const ratio = Number(getContrastRatio(fgHex, bgHex).toFixed(2));
  return {
    fgHex,
    bgHex,
    ratio,
    aaNormal: ratio >= 4.5,
    aaLarge: ratio >= 3.0,
    aaaNormal: ratio >= 7.0,
    aaaLarge: ratio >= 4.5,
  };
}

// Shortest circular angle distance between two hues
export function hueDistance(h1: number, h2: number): number {
  const d = Math.abs(h1 - h2) % 360;
  return d > 180 ? 360 - d : d;
}

// Color blindness simulation (using standard Brettel / Viénot LMS matrices)
export type ColorBlindnessType = 'normal' | 'protanopia' | 'deuteranopia' | 'tritanopia' | 'achromatopsia';

export function simulateColorBlindness(hex: string, type: ColorBlindnessType): string {
  if (type === 'normal') return hex;
  const rgb = hexToRgb(hex);
  let r = rgb.r / 255;
  let g = rgb.g / 255;
  let b = rgb.b / 255;

  let sr = r, sg = g, sb = b;

  if (type === 'protanopia') {
    // Red-blind
    sr = 0.56667 * r + 0.43333 * g + 0.0 * b;
    sg = 0.55833 * r + 0.44167 * g + 0.0 * b;
    sb = 0.0 * r + 0.24167 * g + 0.75833 * b;
  } else if (type === 'deuteranopia') {
    // Green-blind
    sr = 0.625 * r + 0.375 * g + 0.0 * b;
    sg = 0.70 * r + 0.30 * g + 0.0 * b;
    sb = 0.0 * r + 0.30 * g + 0.70 * b;
  } else if (type === 'tritanopia') {
    // Blue-blind
    sr = 0.95 * r + 0.05 * g + 0.0 * b;
    sg = 0.0 * r + 0.43333 * g + 0.56667 * b;
    sb = 0.0 * r + 0.475 * g + 0.525 * b;
  } else if (type === 'achromatopsia') {
    // Total color blindness (Luminance)
    const lum = 0.299 * r + 0.587 * g + 0.114 * b;
    sr = lum;
    sg = lum;
    sb = lum;
  }

  return rgbToHex(sr * 255, sg * 255, sb * 255);
}

/**
 * Classifies the color harmony of up to 4 colors.
 */
export function analyzeHarmony(hexColors: string[]): HarmonyResult {
  const colors = hexColors.filter(c => /^#[0-9A-Fa-f]{6}$/i.test(c));
  if (colors.length < 2) {
    return {
      type: 'Monochromatic',
      confidence: 100,
      description: 'Single color selected. Adjust hues to explore harmony relationships.',
      angleDeviations: [],
      recommendation: 'Add another color to form a harmony pair.',
      isStandardHarmony: true,
    };
  }

  const hslList = colors.map(hexToHsl);

  // Filter out pure grays (saturation < 10) for hue geometry comparison, but note their presence
  const saturatedHues = hslList.filter(c => c.s >= 10).map(c => c.h);

  // 1. Check Monochromatic (all saturated hues within 15° of each other)
  if (saturatedHues.length <= 1) {
    return {
      type: 'Monochromatic',
      confidence: 96,
      description: 'Shares a single base hue with variations in lightness and saturation.',
      angleDeviations: [0],
      recommendation: 'Ideal for understated, cohesive, and elegant branding or clean app backgrounds.',
      isStandardHarmony: true,
    };
  }

  const maxHueDiff = Math.max(...saturatedHues.map((h1, i) =>
    Math.max(...saturatedHues.slice(i + 1).map(h2 => hueDistance(h1, h2)))
  ));

  if (maxHueDiff <= 18) {
    return {
      type: 'Monochromatic',
      confidence: Math.round(100 - maxHueDiff * 2),
      description: 'All colors share the same hue family with nuanced lightness/saturation shifts.',
      angleDeviations: [maxHueDiff],
      recommendation: 'Ensure at least one color has strong lightness contrast (L > 80% or L < 20%) for text legibility.',
      isStandardHarmony: true,
    };
  }

  // 2. Check Analogous (all hues within a ~45° wedge, adjacent on the wheel)
  const sortedHues = [...saturatedHues].sort((a, b) => a - b);
  let isAnalogous = true;
  let maxAdjacentSpread = 0;
  for (let i = 0; i < sortedHues.length; i++) {
    for (let j = i + 1; j < sortedHues.length; j++) {
      const dist = hueDistance(sortedHues[i], sortedHues[j]);
      if (dist > 65) isAnalogous = false;
      if (dist > maxAdjacentSpread) maxAdjacentSpread = dist;
    }
  }

  if (isAnalogous && maxAdjacentSpread <= 65) {
    const conf = Math.max(70, Math.round(100 - Math.abs(maxAdjacentSpread - 40)));
    return {
      type: 'Analogous',
      confidence: conf,
      description: 'Colors sit side-by-side on the wheel (within 60°), evoking calm, natural harmony and serene gradients.',
      angleDeviations: [maxAdjacentSpread],
      recommendation: 'Choose one hue as dominant and use the others as gentle supporting accents.',
      isStandardHarmony: true,
    };
  }

  // If exactly 2 colors: check Complementary
  if (colors.length === 2) {
    const dist = hueDistance(hslList[0].h, hslList[1].h);
    const deviation = Math.abs(dist - 180);
    if (deviation <= 30) {
      const conf = Math.round(100 - deviation * 2);
      return {
        type: 'Complementary',
        confidence: conf,
        description: `Opposite hues on the color wheel (~${Math.round(dist)}° separation). Maximum chromatic contrast and high energy.`,
        angleDeviations: [deviation],
        recommendation: 'Use one color for 80-90% of surfaces and the complement strictly as a focal CTA accent.',
        isStandardHarmony: true,
      };
    }
  }

  // Check 3 colors: Triadic or Split-Complementary
  if (colors.length === 3) {
    const [h1, h2, h3] = hslList.map(c => c.h);
    const d12 = hueDistance(h1, h2);
    const d23 = hueDistance(h2, h3);
    const d31 = hueDistance(h3, h1);

    // Triadic target: 120°, 120°, 120°
    const triadicDev = (Math.abs(d12 - 120) + Math.abs(d23 - 120) + Math.abs(d31 - 120)) / 3;
    if (triadicDev <= 24) {
      return {
        type: 'Triadic',
        confidence: Math.round(100 - triadicDev * 2.5),
        description: 'Forms an equilateral triangle on the color wheel (120° apart). Vibrant and richly balanced.',
        angleDeviations: [Math.round(triadicDev)],
        recommendation: 'Let one color dominate, while using the other two for supporting elements and badges.',
        isStandardHarmony: true,
      };
    }

    // Split-Complementary target: One base, two colors adjacent to its complement (150° and 210°, or ~30° apart from each other and ~150° from base)
    const pairs = [
      { base: h1, a: h2, b: h3 },
      { base: h2, a: h1, b: h3 },
      { base: h3, a: h1, b: h2 },
    ];
    for (const p of pairs) {
      const distA = hueDistance(p.base, p.a);
      const distB = hueDistance(p.base, p.b);
      const distBetween = hueDistance(p.a, p.b);
      if (Math.abs(distA - 150) <= 25 && Math.abs(distB - 150) <= 25 && distBetween <= 60) {
        return {
          type: 'Split-Complementary',
          confidence: Math.round(95 - (Math.abs(distA - 150) + Math.abs(distB - 150)) / 2),
          description: 'A base hue paired with the two colors adjacent to its complement. High contrast with less visual tension than pure complement.',
          angleDeviations: [Math.round(Math.abs(distA - 150))],
          recommendation: 'Excellent for user interfaces. Use the base hue as the primary brand, and the split hues for interactive CTAs.',
          isStandardHarmony: true,
        };
      }
    }
  }

  // Check 4 colors: Tetradic (Rectangular) or Square
  if (colors.length === 4) {
    const hues = hslList.map(c => c.h).sort((a, b) => a - b);
    // Square target: ~90° intervals
    const diffs = [
      hueDistance(hues[0], hues[1]),
      hueDistance(hues[1], hues[2]),
      hueDistance(hues[2], hues[3]),
      hueDistance(hues[3], hues[0]),
    ];
    const squareDev = diffs.reduce((sum, d) => sum + Math.abs(d - 90), 0) / 4;
    if (squareDev <= 22) {
      return {
        type: 'Square',
        confidence: Math.round(100 - squareDev * 2.5),
        description: 'Four colors spaced evenly at 90° intervals around the wheel. Rich, bold, and dynamic.',
        angleDeviations: [Math.round(squareDev)],
        recommendation: 'Pay close attention to balance: prioritize 1 warm and 1 cool hue to prevent a chaotic appearance.',
        isStandardHarmony: true,
      };
    }

    // Tetradic / Rectangular: Two complementary pairs
    const d02 = hueDistance(hues[0], hues[2]);
    const d13 = hueDistance(hues[1], hues[3]);
    if (Math.abs(d02 - 180) <= 30 && Math.abs(d13 - 180) <= 30) {
      return {
        type: 'Tetradic',
        confidence: Math.round(92 - (Math.abs(d02 - 180) + Math.abs(d13 - 180)) / 2),
        description: 'Two complementary pairs forming a rectangle on the wheel. Highly versatile with broad chromatic range.',
        angleDeviations: [Math.round(Math.abs(d02 - 180))],
        recommendation: 'Avoid equal distribution. Pick one dominant color and soften the saturation of at least two others.',
        isStandardHarmony: true,
      };
    }
  }

  // If no standard geometry matched closely
  return {
    type: 'Custom / Discordant',
    confidence: 62,
    description: 'Hues do not follow a classical geometric wheel configuration (angles are asymmetric or irregular).',
    angleDeviations: [],
    recommendation: 'Consider nudging one or two hues to match Complementary, Split-Complementary, or Triadic geometry for cleaner aesthetic flow.',
    isStandardHarmony: false,
  };
}

/**
 * Evaluates whether the combination is "pleasing" and returns deep reasons why.
 */
export function evaluateAestheticPleasingness(hexColors: string[]): AestheticAnalysis {
  const colors = hexColors.filter(c => /^#[0-9A-Fa-f]{6}$/i.test(c));
  if (colors.length < 2) {
    return {
      overallScore: 70,
      ratingText: 'Harmonious & Refined',
      harmonyScore: 80,
      luminanceSpreadScore: 70,
      saturationBalanceScore: 80,
      temperatureBalance: 'Neutral/Monochrome',
      vibrationWarning: false,
      strengths: ['Single focused color anchor'],
      weaknesses: ['Needs complementary tones to evaluate full contrast'],
      whyExplanation: 'A single color has inherent internal consistency.',
      actionableSuggestions: ['Add more colors to test interactive palette harmonies.'],
    };
  }

  const hslList = colors.map(hexToHsl);
  const rgbList = colors.map(hexToRgb);
  const luminances = rgbList.map(getRelativeLuminance);
  const harmony = analyzeHarmony(colors);

  // 1. Luminance Spread (Dynamic Range)
  const minLum = Math.min(...luminances);
  const maxLum = Math.max(...luminances);
  const lumDelta = maxLum - minLum;
  // A good UI palette usually has lumDelta >= 0.45 (at least one dark and one light element)
  let luminanceSpreadScore = Math.min(100, Math.round(lumDelta * 140));
  if (lumDelta < 0.2) luminanceSpreadScore = Math.max(20, Math.round(lumDelta * 100));

  // 2. Saturation Balance
  // If all colors have 100% saturation, it causes cognitive eye fatigue (AI/carnival slop)
  const maxS = Math.max(...hslList.map(c => c.s));
  const minS = Math.min(...hslList.map(c => c.s));
  const avgS = hslList.reduce((acc, c) => acc + c.s, 0) / hslList.length;
  let saturationBalanceScore = 85;
  if (avgS > 88 && minS > 80) {
    // Over-saturated!
    saturationBalanceScore = 45;
  } else if (avgS < 15) {
    // Very muted / washed out
    saturationBalanceScore = 70;
  } else if (maxS - minS > 35) {
    // Good hierarchy: some vibrant accents, some grounding neutrals
    saturationBalanceScore = 95;
  }

  // 3. Chromatic Vibration (Equiluminant high-chroma adjacent clash)
  let vibrationWarning = false;
  let vibrationPair: [string, string] | undefined = undefined;

  for (let i = 0; i < colors.length; i++) {
    for (let j = i + 1; j < colors.length; j++) {
      const c1 = hslList[i];
      const c2 = hslList[j];
      const dist = hueDistance(c1.h, c2.h);
      const lumDiff = Math.abs(luminances[i] - luminances[j]);
      // If two colors have high saturation (> 70), distant hues (> 100°), and virtually identical luminance (< 0.12)
      // They produce an optic vibrating edge effect that hurts human eyes
      if (c1.s > 65 && c2.s > 65 && dist > 110 && lumDiff < 0.12) {
        vibrationWarning = true;
        vibrationPair = [colors[i], colors[j]];
        break;
      }
    }
    if (vibrationWarning) break;
  }

  // 4. Temperature Balance
  const warmCount = hslList.filter(c => (c.h >= 0 && c.h <= 75) || c.h >= 315).length;
  const coolCount = hslList.filter(c => c.h > 75 && c.h < 315).length;
  let temperatureBalance: AestheticAnalysis['temperatureBalance'] = 'Balanced Warm/Cool';
  if (warmCount > coolCount && coolCount === 0) temperatureBalance = 'Warm Dominant';
  else if (coolCount > warmCount && warmCount === 0) temperatureBalance = 'Cool Dominant';
  else if (hslList.every(c => c.s < 12)) temperatureBalance = 'Neutral/Monochrome';

  // Overall Score Calculation
  const harmonyWeight = harmony.isStandardHarmony ? harmony.confidence : 50;
  let penalty = 0;
  if (vibrationWarning) penalty += 25;
  if (luminanceSpreadScore < 40) penalty += 15;
  if (saturationBalanceScore < 50) penalty += 15;

  const rawScore = (harmonyWeight * 0.4) + (luminanceSpreadScore * 0.35) + (saturationBalanceScore * 0.25) - penalty;
  const overallScore = Math.max(15, Math.min(98, Math.round(rawScore)));

  let ratingText: AestheticAnalysis['ratingText'] = 'Balanced & Pleasing';
  if (overallScore >= 85) ratingText = 'Harmonious & Refined';
  else if (overallScore >= 72) ratingText = 'Balanced & Pleasing';
  else if (overallScore >= 60) ratingText = 'Vibrant with High Energy';
  else if (overallScore >= 45) ratingText = 'Slightly Tensioned';
  else ratingText = 'Clashing / Fatiguing';

  // Compile Strengths & Weaknesses
  const strengths: string[] = [];
  const weaknesses: string[] = [];
  const actionableSuggestions: string[] = [];

  if (harmony.isStandardHarmony) {
    strengths.push(`Aligns with recognized ${harmony.type} wheel geometry (${harmony.confidence}% precision).`);
  } else {
    weaknesses.push('Hues have non-standard angular separation, which can read as chaotic.');
    actionableSuggestions.push('Use the 1-Tap Harmonizer to shift hues into a clean Triadic or Complementary chord.');
  }

  if (lumDelta >= 0.5) {
    strengths.push(`Strong value contrast (luminance delta ${lumDelta.toFixed(2)}): provides clear visual hierarchy.`);
  } else {
    weaknesses.push(`Low luminance variation (delta ${lumDelta.toFixed(2)}): colors may blur together or look muddy.`);
    actionableSuggestions.push('Increase the lightness of your lightest swatch or darken the darkest to establish crisp contrast.');
  }

  if (vibrationWarning && vibrationPair) {
    weaknesses.push(`Equiluminant chromatic vibration detected between ${vibrationPair[0]} and ${vibrationPair[1]}. The borders will appear to flutter.`);
    actionableSuggestions.push(`Separate ${vibrationPair[0]} and ${vibrationPair[1]} by either darkening one, or introducing a neutral divider.`);
  }

  if (avgS > 85 && minS > 75) {
    weaknesses.push('High saturation across all colors competes for optical attention without resting zones.');
    actionableSuggestions.push('Desaturate secondary and background colors to 15-35%, keeping high saturation strictly for your hero accent.');
  } else if (maxS - minS > 30) {
    strengths.push('Thoughtful saturation rhythm: pairs grounded neutrals with vivid focal accents.');
  }

  // Plain-Language Comprehensive "Why" Explanation
  let whyExplanation = '';
  if (overallScore >= 80) {
    whyExplanation = `This combination is highly pleasing because it successfully couples geometric ${harmony.type.toLowerCase()} balance with deliberate lightness hierarchy. The eye naturally understands the visual order, avoiding sensory overload while delivering memorable aesthetic depth.`;
  } else if (overallScore >= 60) {
    whyExplanation = `This combination has energetic character and works decently, but suffers from slight visual competition. The colors have distinct personalities, yet without clearer value separation (light vs dark) or neutral breathing room, it may cause visual fatigue in complex layouts.`;
  } else {
    whyExplanation = `This combination feels discordant or uncomfortable because ${
      vibrationWarning 
        ? 'it produces optical vibration where two intense saturated colors meet at identical luminance'
        : 'the hue intervals create chromatic tension without enough value contrast to establish a clear focal point'
    }. In graphic and UI design, human eyes crave a dominant anchor rather than equal competing stimuli.`;
  }

  return {
    overallScore,
    ratingText,
    harmonyScore: harmony.confidence,
    luminanceSpreadScore,
    saturationBalanceScore,
    temperatureBalance,
    vibrationWarning,
    vibrationPair,
    strengths,
    weaknesses,
    whyExplanation,
    actionableSuggestions,
  };
}

/**
 * 1-Tap Smart Harmonizer: Nudges the input colors into optimal theoretical alignment
 * and WCAG-friendly contrast ratios.
 */
export function harmonizePalette(hexColors: string[], targetHarmony?: HarmonyResult['type']): string[] {
  if (hexColors.length === 0) return ['#2563EB', '#F59E0B', '#10B981', '#6366F1'];
  const baseHsl = hexToHsl(hexColors[0]);
  const baseHue = baseHsl.h;

  const count = Math.min(4, Math.max(2, hexColors.length));

  if (count === 2) {
    // Complementary with proper light/dark contrast
    return [
      hslToHex(baseHue, Math.min(85, Math.max(50, baseHsl.s)), 45), // Main
      hslToHex((baseHue + 180) % 360, Math.min(95, Math.max(65, baseHsl.s)), 75), // Light complement
    ];
  }

  if (count === 3) {
    // Split-Complementary or Triadic
    const useTriadic = targetHarmony === 'Triadic';
    if (useTriadic) {
      return [
        hslToHex(baseHue, 65, 40), // Dominant base
        hslToHex((baseHue + 120) % 360, 75, 60), // Triad 2
        hslToHex((baseHue + 240) % 360, 50, 85), // Soft Triad 3
      ];
    } else {
      return [
        hslToHex(baseHue, 70, 35), // Base dominant
        hslToHex((baseHue + 150) % 360, 85, 65), // Split 1
        hslToHex((baseHue + 210) % 360, 60, 85), // Split 2
      ];
    }
  }

  // 4 Colors: Complete 60-30-10 Android System (Dominant, Secondary, Accent, Surface)
  return [
    hslToHex(baseHue, 60, 20), // 60% Dominant deep surface
    hslToHex((baseHue + 30) % 360, 45, 50), // 30% Secondary structure
    hslToHex((baseHue + 180) % 360, 90, 60), // 10% Vibrant complementary accent
    hslToHex((baseHue + 15) % 360, 20, 96), // Clean high-contrast text/surface
  ];
}

/**
 * Generate theoretical palettes from scratch
 */
export function generateTheoryPalette(baseHex: string, harmonyType: string): string[] {
  const { h, s } = hexToHsl(baseHex);
  switch (harmonyType) {
    case 'Complementary':
      return [
        hslToHex(h, s, 35),
        hslToHex(h, Math.max(30, s - 20), 85),
        hslToHex((h + 180) % 360, Math.min(100, s + 15), 55),
        hslToHex((h + 180) % 360, 25, 95),
      ];
    case 'Analogous':
      return [
        hslToHex(h, s, 45),
        hslToHex((h + 30) % 360, s, 55),
        hslToHex((h + 60) % 360, Math.max(35, s - 10), 65),
        hslToHex((h - 30 + 360) % 360, 25, 92),
      ];
    case 'Triadic':
      return [
        hslToHex(h, s, 40),
        hslToHex((h + 120) % 360, Math.min(90, s + 10), 55),
        hslToHex((h + 240) % 360, Math.max(40, s - 15), 65),
        hslToHex(h, 15, 96),
      ];
    case 'Split-Complementary':
      return [
        hslToHex(h, s, 38),
        hslToHex((h + 150) % 360, s, 60),
        hslToHex((h + 210) % 360, Math.max(40, s - 10), 50),
        hslToHex((h + 180) % 360, 20, 95),
      ];
    case 'Tetradic':
      return [
        hslToHex(h, s, 42),
        hslToHex((h + 60) % 360, Math.max(40, s - 15), 55),
        hslToHex((h + 180) % 360, s, 65),
        hslToHex((h + 240) % 360, 50, 80),
      ];
    case 'Square':
      return [
        hslToHex(h, s, 40),
        hslToHex((h + 90) % 360, s, 50),
        hslToHex((h + 180) % 360, s, 60),
        hslToHex((h + 270) % 360, s, 70),
      ];
    case 'Monochromatic':
    default:
      return [
        hslToHex(h, s, 20),
        hslToHex(h, Math.max(30, s - 15), 45),
        hslToHex(h, Math.max(20, s - 30), 70),
        hslToHex(h, Math.max(10, s - 40), 92),
      ];
  }
}
