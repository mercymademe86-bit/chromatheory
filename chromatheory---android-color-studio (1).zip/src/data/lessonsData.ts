export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  exampleColors?: string[];
}

export interface Lesson {
  id: string;
  title: string;
  shortTitle: string;
  tagline: string;
  category: 'Fundamentals' | 'Harmonies' | 'Perception & Temperature';
  readTime: string;
  iconName: string;
  summary: string;
  keyPoints: string[];
  demoColors: string[];
  deepDive: {
    sectionTitle: string;
    paragraphs: string[];
    visualType: 'wheel' | 'temperature' | 'monochrome_slider' | 'complement_slider' | 'triad_triangle' | 'tetrad_box';
  }[];
  quiz: QuizQuestion[];
}

export const COLOR_THEORY_LESSONS: Lesson[] = [
  {
    id: 'color-wheel',
    title: 'The Color Wheel & Anatomy',
    shortTitle: 'Color Wheel',
    tagline: 'From Newton’s circular prism to modern HSL coordinates',
    category: 'Fundamentals',
    readTime: '4 min',
    iconName: 'Disc',
    summary: 'The color wheel arranges 12 hues in a circle, establishing the mathematical foundation for all chromatic harmony and digital displays.',
    keyPoints: [
      'Primary Colors: Red, Yellow, Blue in pigment (RYB) / Red, Green, Blue in light (RGB).',
      'Secondary Colors: Created by mixing two primaries (Orange, Green, Purple).',
      'Tertiary Colors: Formed by combining a primary with an adjacent secondary (e.g. Red-Orange, Blue-Green).',
      'HSL Coordinates: Hue (0-360° position), Saturation (0-100% purity), Lightness (0-100% white to black).',
    ],
    demoColors: ['#EF4444', '#F59E0B', '#10B981', '#3B82F6', '#8B5CF6'],
    deepDive: [
      {
        sectionTitle: 'How the 360° Wheel Organizes Visual Thought',
        paragraphs: [
          'In 1666, Sir Isaac Newton passed sunlight through a glass prism, splitting white light into the visible spectrum, then bent that ribbon of light into a circle. By connecting the violet end back to red, he revealed the cyclic relationships of color.',
          'In modern digital screens, every color lives on a 360° polar coordinate system: 0° is pure Red, 120° is pure Green, and 240° is pure Blue. When you select an analogous hue, you are simply shifting by ±30°; when you choose a complement, you rotate 180° across the diameter.',
        ],
        visualType: 'wheel',
      },
      {
        sectionTitle: 'Hue, Tint, Tone, and Shade',
        paragraphs: [
          'A pure hue is saturated color at full wavelength. A Tint is made by adding white (increasing lightness). A Shade is created by adding black (decreasing lightness). A Tone is achieved by adding gray or desaturating (lowering chroma).',
          'Mastering tints and shades is what separates beginner "rainbow clashing" from professional, sophisticated mobile UI palettes.',
        ],
        visualType: 'monochrome_slider',
      },
    ],
    quiz: [
      {
        id: 'qw-1',
        question: 'Which of the following is an example of a tertiary color?',
        options: ['Orange', 'Yellow-Green', 'Purple', 'Green'],
        correctIndex: 1,
        explanation: 'Yellow-Green is created by mixing the primary color Yellow with the adjacent secondary color Green.',
        exampleColors: ['#EAB308', '#84CC16', '#22C55E'],
      },
      {
        id: 'qw-2',
        question: 'In the 360° HSL color wheel, how many degrees separate pure Red (0°) from pure Blue (240°)?',
        options: ['60°', '120°', '240° (or 120° in the reverse direction)', '180°'],
        correctIndex: 2,
        explanation: 'On the circular wheel, 240° forward or 120° backward separates Red from Blue.',
      },
    ],
  },
  {
    id: 'complementary',
    title: 'Complementary Harmony',
    shortTitle: 'Complementary',
    tagline: 'High-voltage contrast from polar opposites (180°)',
    category: 'Harmonies',
    readTime: '3 min',
    iconName: 'ArrowLeftRight',
    summary: 'Complementary colors sit exactly opposite each other on the color wheel (180° apart), maximizing optical contrast and dynamic energy.',
    keyPoints: [
      'Maximum optical contrast: Blue & Orange, Red & Green, Yellow & Purple.',
      'Simultaneous Contrast: Placing them side-by-side intensifies perceived brightness.',
      'UI Best Practice: Avoid 50/50 area splits. Use 90% of one color and 10% of the complement for call-to-action buttons.',
      'Risk of Vibration: High-chroma complementary pairs at equal luminance produce uncomfortable optical fluttering.',
    ],
    demoColors: ['#1E3A8A', '#F97316'],
    deepDive: [
      {
        sectionTitle: 'The Optical Power of 180° Opposition',
        paragraphs: [
          'When the human eye stares at a vibrant color, the photoreceptor cones fatigue, and looking away instantly reveals an after-image of its exact complement. This biological phenomenon makes complementary pairs the most visually energetic pairings in human perception.',
          'In Android and product design, complementary colors are your secret weapon for call-to-action (CTA) clarity. A deep navy app interface with a warm amber-orange confirmation button instantly directs the user’s thumb without cognitive friction.',
        ],
        visualType: 'complement_slider',
      },
    ],
    quiz: [
      {
        id: 'qc-1',
        question: 'What happens when two pure complementary colors meet at identical luminance and high saturation?',
        options: [
          'They blend seamlessly without tension',
          'They create an optical vibrating edge that fatigues human eyes',
          'They turn completely monochromatic',
          'They cancel out into transparent pixels',
        ],
        correctIndex: 1,
        explanation: 'Equiluminant high-chroma complements stimulate competing cone cells simultaneously, causing optical vibration along the border.',
      },
      {
        id: 'qc-2',
        question: 'What is the recommended area balance when using complementary colors in UI design?',
        options: [
          '50% Dominant / 50% Complement',
          '80-90% Neutral/Dominant surface, with 10-20% Complement strictly as an accent',
          'Use only complements for body text on white backgrounds',
          'Always use 4 equal quadrants',
        ],
        correctIndex: 1,
        explanation: 'Giving one color clear dominance while using the complement as a focal highlight creates clear hierarchy without visual chaos.',
      },
    ],
  },
  {
    id: 'triadic',
    title: 'Triadic Harmonies',
    shortTitle: 'Triadic',
    tagline: 'Vibrant equilibrium through equilateral balance (120°)',
    category: 'Harmonies',
    readTime: '3 min',
    iconName: 'Triangle',
    summary: 'Triadic schemes use three colors spaced evenly at 120° angles around the wheel, offering rich chromatic variety while maintaining natural balance.',
    keyPoints: [
      'Equilateral geometry: 3 hues separated by 120° intervals.',
      'Classic examples: Red, Yellow, Blue (Primary triad); Purple, Green, Orange (Secondary triad).',
      'Dynamic yet stable: Balances visual stimulation across multiple color families.',
      'UI Execution: Designate one dominant tone, one secondary support, and the third strictly for alerts or micro-accents.',
    ],
    demoColors: ['#2563EB', '#E11D48', '#F59E0B'],
    deepDive: [
      {
        sectionTitle: 'The Art of Triadic Subordination',
        paragraphs: [
          'Triadic palettes are beloved by illustrators and brand identity designers because they feel playful, lively, and optimistic without dissolving into visual noise.',
          'However, in digital applications, using all three colors at 100% saturation simultaneously causes a "comic book / toy box" effect. The master technique is Triadic Subordination: keep one hue deeply saturated (e.g. Navy Blue), desaturate the second into a subtle tint (e.g. Sage Green surface), and retain the third for vibrant clicks (e.g. Coral Pink).',
        ],
        visualType: 'triad_triangle',
      },
    ],
    quiz: [
      {
        id: 'qt-1',
        question: 'What angle on the color wheel defines a Triadic harmony?',
        options: ['90°', '120°', '180°', '60°'],
        correctIndex: 1,
        explanation: 'Triadic colors form an equilateral triangle with 120° between each of the three points.',
      },
    ],
  },
  {
    id: 'tetradic',
    title: 'Tetradic & Square Schemes',
    shortTitle: 'Tetradic & Square',
    tagline: 'Four-point chromatic richness and dual complementary chords',
    category: 'Harmonies',
    readTime: '4 min',
    iconName: 'Square',
    summary: 'Tetradic (rectangular) and Square palettes utilize four colors arranged in complementary pairs, offering the richest possible chromatic range.',
    keyPoints: [
      'Square: 4 colors spaced equally at 90° intervals.',
      'Tetradic (Rectangle): Two complementary pairs with varying spacing (e.g. 60° and 180°).',
      'High complexity: Difficult to balance without a disciplined hierarchy.',
      'Golden Rule: Never use all 4 colors in equal quantities; assign roles (Dominant, Secondary, Accent 1, Accent 2).',
    ],
    demoColors: ['#0F766E', '#C026D3', '#F97316', '#2563EB'],
    deepDive: [
      {
        sectionTitle: 'Managing Four Competing Chromatic Forces',
        paragraphs: [
          'Because a tetradic scheme contains two pairs of complementary colors, it introduces the most chromatic tension of any standard harmony. When done poorly, it reads as fragmented and distracting.',
          'To master tetradic design, always skew the temperature: let one warm color lead, anchor it with two neutral or desaturated cool tones, and use the fourth color sparingly for badges or micro-badges.',
        ],
        visualType: 'tetrad_box',
      },
    ],
    quiz: [
      {
        id: 'qt-2',
        question: 'What is the main danger when applying a Tetradic (4-color) palette in UI design?',
        options: [
          'The colors will all look identical',
          'Without clear hierarchy, the four colors fight for optical dominance and create confusion',
          'Tetradic colors cannot be rendered on OLED screens',
          'Tetradic palettes are prohibited by WCAG standards',
        ],
        correctIndex: 1,
        explanation: 'With four distinct hues, equal visual weighting creates chaos. One hue must dominate while others play strictly supportive roles.',
      },
    ],
  },
  {
    id: 'monochromatic',
    title: 'Monochromatic Schemes',
    shortTitle: 'Monochromatic',
    tagline: 'Nuance, elegance, and guaranteed harmony from a single hue',
    category: 'Harmonies',
    readTime: '3 min',
    iconName: 'Layers',
    summary: 'Monochromatic palettes explore the depth of a single hue by altering saturation and lightness, creating inherently cohesive and tranquil designs.',
    keyPoints: [
      'Single base hue: 0° angle difference.',
      'Variation through Tints (adding white) and Shades (adding black).',
      'Effortless harmony: Guaranteed never to clash.',
      'Essential requirement: Must have wide lightness spread (luminance delta > 0.6) for text legibility.',
    ],
    demoColors: ['#1E1B4B', '#312E81', '#4F46E5', '#818CF8', '#EEF2FF'],
    deepDive: [
      {
        sectionTitle: 'The Architecture of Clean Luxury',
        paragraphs: [
          'From high-end fashion to modern editorial interfaces, monochromatic color palettes represent confidence and serenity. Because there is no chromatic competition, user attention flows seamlessly to typography, content, and imagery.',
          'The key to successful monochrome is value depth: you need at least one very dark shade (for text or deep surfaces) and at least one luminous tint (for clean contrast), with mid-tones reserved for subtle borders and cards.',
        ],
        visualType: 'monochrome_slider',
      },
    ],
    quiz: [
      {
        id: 'qm-1',
        question: 'What is the most critical factor to verify when building a monochromatic UI palette?',
        options: [
          'Ensuring all swatches have identical lightness',
          'Ensuring sufficient lightness/value contrast between text and background surfaces',
          'Adding a random rainbow accent every 3 screens',
          'Setting saturation to 100% on every swatch',
        ],
        correctIndex: 1,
        explanation: 'Without value contrast, monochromatic interfaces become illegible gray smudges. Lightness range is crucial for accessibility.',
      },
    ],
  },
  {
    id: 'warm-cool',
    title: 'Warm vs. Cool Colors & Psychology',
    shortTitle: 'Warm vs Cool',
    tagline: 'Spatial depth, advancing hues, and emotional resonance',
    category: 'Perception & Temperature',
    readTime: '4 min',
    iconName: 'Flame',
    summary: 'Color temperature influences how we perceive depth: warm colors advance toward the viewer, while cool colors recede, directly evoking visceral emotional responses.',
    keyPoints: [
      'Warm Colors (Reds, Oranges, Yellows): Evoke energy, warmth, urgency, and appetites. They visually advance.',
      'Cool Colors (Blues, Greens, Purples): Evoke calm, trust, stability, and professionalism. They visually recede.',
      'Atmospheric Depth: Placing warm elements over cool backgrounds creates an intuitive sense of 3D layering.',
      'Cultural and Psychological Context: Blue communicates security in fintech; red demands rapid attention in alerts.',
    ],
    demoColors: ['#DC2626', '#EA580C', '#0284C7', '#0D9488'],
    deepDive: [
      {
        sectionTitle: 'Spatial Dynamics: Why Warm Colors "Pop"',
        paragraphs: [
          'Due to the chromatic aberration of the human lens, longer wavelengths of light (reds and oranges) focus slightly behind the retina, causing the eye lens to thicken. As a result, warm colors literally appear closer to the viewer than cool wavelengths.',
          'This is why notification badges, warning dialogs, and primary sale CTAs are universally warm: biology naturally pulls your gaze toward them first.',
        ],
        visualType: 'temperature',
      },
    ],
    quiz: [
      {
        id: 'qwc-1',
        question: 'Why do warm colors (reds, oranges) appear to advance toward the viewer in a layout?',
        options: [
          'They carry higher pixel resolution',
          'Due to biological lens focus and wavelength perception, human eyes perceive them as spatially closer',
          'Because screens brighten red LEDs by 50%',
          'They are always placed on top of other layers in HTML',
        ],
        correctIndex: 1,
        explanation: 'Longer wavelengths of light cause the lens to perceive warm colors as closer, making them naturally advance.',
      },
      {
        id: 'qwc-2',
        question: 'Which color temperature combination creates natural spatial depth in user interfaces?',
        options: [
          'Hot orange text on bright yellow backgrounds',
          'Warm foreground interactive elements placed over calming, receded cool background surfaces',
          'Pure black on pure gray',
          'Only cool colors with zero warm accents',
        ],
        correctIndex: 1,
        explanation: 'Cool receded backgrounds paired with warm advancing accents create intuitive visual layering and hierarchy.',
      },
    ],
  },
];
